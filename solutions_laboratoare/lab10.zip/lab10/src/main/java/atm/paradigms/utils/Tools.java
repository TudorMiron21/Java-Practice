package atm.paradigms.utils;

import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import atm.paradigms.Mapper;


public class Tools {
    private static SqlSessionFactory factory = null;
    // thread safe method
    public static SqlSessionFactory getSqlSessionFactory() throws IOException{
        if (factory == null){
            String resource = "mybatis-config.xml";
            Reader reader = Resources.getResourceAsReader(resource);
            factory = new SqlSessionFactoryBuilder().build(reader);
            factory.getConfiguration().addMapper(Mapper.class);
            reader.close();
        }
        return factory;
    }
}
