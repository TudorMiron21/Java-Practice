package atm.paradigms.model;

public class Agent {
    private int id;
    private String name;
    private String working_area;
    private double commission;
    private String phone_no;
    private String country;

    public Agent() {
    }

    public Agent(String name, String working_area, double commission, String phone_no, String country) {
        this.name = name;
        this.working_area = working_area;
        this.commission = commission;
        this.phone_no = phone_no;
        this.country = country;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWorking_area() {
        return working_area;
    }

    public void setWorking_area(String working_area) {
        this.working_area = working_area;
    }

    public double getCommission() {
        return commission;
    }

    public void setCommission(double commission) {
        this.commission = commission;
    }

    public String getPhone_no() {
        return phone_no;
    }

    public void setPhone_no(String phone_no) {
        this.phone_no = phone_no;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return "Agent [id=" + id + ", name=" + name + ", working_area=" + working_area + ", commission=" + commission
                + ", phone_no=" + phone_no + ", country=" + country + "]";
    }

}
