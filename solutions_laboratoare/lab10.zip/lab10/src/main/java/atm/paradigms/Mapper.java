package atm.paradigms;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import atm.paradigms.model.Agent;

public interface Mapper {
    @Select("SELECT * FROM agents")
    public List<Agent> getAgents();

    @Select("SELECT * FROM agents WHERE Id = #{id}")
    public Agent getAgentById(int id);

    @Insert("INSERT INTO agents(NAME, WORKING_AREA, COMMISSION, PHONE_NO, COUNTRY) "
    + "VALUES(#{name}, #{working_area}, #{commission}, #{phone_no}, #{country})")
    public void insertAgent(Agent agent);

    @Update("UPDATE agents SET NAME=#{name}, WORKING_AREA=#{working_area}, COMMISSION=#{commission}, "
    + "PHONE_NO=#{phone_no}, COUNTRY=#{country} WHERE Id = #{id}")
    public void updateAgent(Agent agent);

    @Delete("DELETE FROM agents WHERE Id = #{id}")
    public void deleteAgentById(int id);
}
