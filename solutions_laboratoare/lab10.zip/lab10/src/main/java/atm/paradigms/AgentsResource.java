package atm.paradigms;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import atm.paradigms.model.Agent;
import atm.paradigms.utils.Tools;

@Path("agents")
public class AgentsResource {
    private static final Logger logger = Logger.getLogger(AgentsResource.class.getName());

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAgents() {
        try {
            SqlSessionFactory factory = Tools.getSqlSessionFactory();
            try (SqlSession session = factory.openSession()) {
                List<Agent> agents = session.selectList("getAgents");
                return Response.ok().entity(agents).build();
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.toString());
            ObjectMapper om = new ObjectMapper();
            ObjectNode node = om.createObjectNode();
            node.put("message", "An error occured. Check on server.");
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(node.toString()).build();
        }
    }

    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAgentById(@PathParam("id") int id) {
        try {
            SqlSessionFactory factory = Tools.getSqlSessionFactory();
            try (SqlSession session = factory.openSession()) {
                Agent agent = session.selectOne("getAgentById", id);
                return Response.ok().entity(agent).build();
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.toString());
            ObjectMapper om = new ObjectMapper();
            ObjectNode node = om.createObjectNode();
            node.put("message", "An error occured. Check on server.");
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(node.toString()).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addAgent(Agent agent){
        ObjectMapper om = new ObjectMapper();
        try{
            SqlSessionFactory factory = Tools.getSqlSessionFactory();
            try(SqlSession session = factory.openSession()){
                session.insert("insertAgent", agent);
                session.commit();
                ObjectNode node = om.createObjectNode();
                node.put("message", "Agent successfully inserted.");
                return Response.status(Status.CREATED).entity(node.toPrettyString()).build();
            }
        } catch (Exception e){
            logger.log(Level.SEVERE, e.toString());
            ObjectNode node = om.createObjectNode();
            node.put("message", "An error occured. Check on server.");
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(node.toString()).build();
        }
    }

    @PUT
    @Path("{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response modifyAgent(@PathParam("id") int id, Agent agent){
        ObjectMapper om = new ObjectMapper();
        try{
            SqlSessionFactory factory = Tools.getSqlSessionFactory();
            try(SqlSession session = factory.openSession()){
                agent.setId(id);
                session.update("updateAgent", agent);
                session.commit();
                ObjectNode node = om.createObjectNode();
                node.put("message", "Agent successfully updated.");
                return Response.status(Status.CREATED).entity(node.toPrettyString()).build();
            }
        } catch (Exception e){
            logger.log(Level.SEVERE, e.toString());
            ObjectNode node = om.createObjectNode();
            node.put("message", "An error occured. Check on server.");
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(node.toString()).build();
        }
    }

    @DELETE
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteAgent(@PathParam("id") int id){
        ObjectMapper om = new ObjectMapper();
        try{
            SqlSessionFactory factory = Tools.getSqlSessionFactory();
            try(SqlSession session = factory.openSession()){
                session.delete("deleteAgentById", id);
                session.commit();
                ObjectNode node = om.createObjectNode();
                node.put("message", "Agent successfully deleted.");
                return Response.status(Status.OK).entity(node.toPrettyString()).build();
            }
        } catch (Exception e){
            logger.log(Level.SEVERE, e.toString());
            ObjectNode node = om.createObjectNode();
            node.put("message", "An error occured. Check on server.");
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(node.toString()).build();
        }       
    }

}
