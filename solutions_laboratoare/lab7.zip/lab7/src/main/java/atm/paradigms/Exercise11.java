package atm.paradigms;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import static java.util.stream.Collectors.toList;

public class Exercise11 {
    public static void main(String[] args) {
        Executor executor = Executors.newFixedThreadPool(10,
                new ThreadFactory() {

                    @Override
                    public Thread newThread(Runnable r) {
                        Thread t = new Thread(r);
                        t.setDaemon(true);
                        return t;
                    }

                });
        List<Transaction> transactions = Arrays.asList(
                new Transaction("A", "Description A"),
                new Transaction("B", "Description B"),
                new Transaction("C", "Description C"),
                new Transaction("D", "Description D"),
                new Transaction("E", "Description E"),
                new Transaction("G", "Description G"),
                new Transaction("H", "Description H"),
                new Transaction("I", "Description I"));

        List<CompletableFuture<String>> futures = transactions.stream()
                .map(t -> CompletableFuture.supplyAsync(() -> CategorizationService.categorize(t), executor))
                .collect(toList());

        List<String> categories = futures.stream()
                .map(CompletableFuture::join)
                .collect(toList());
        System.out.println(categories);
    }
}
