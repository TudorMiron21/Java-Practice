package atm.paradigms;

public class CategorizationService {
    public static String categorize(Transaction transaction){
        Exercise1.sleep(1500);
        return "Category_" + transaction.getId();
    }
}
