package atm.paradigms;

import java.time.Duration;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class Exercise9 {
    public static void main(String[] args) {
        LocalTime time = LocalTime.now();
        Duration duration = Duration.of(5, ChronoUnit.HOURS);
        LocalTime time1 = time.plus(duration);
        System.out.println(time1);
    }
}
