package atm.paradigms;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Exercise10 {
    public static void main(String[] args) {
        LocalDate date = LocalDate.now();
        LocalDate date1 = date
                .plus(2, ChronoUnit.YEARS)
                .plus(1, ChronoUnit.MONTHS)
                .plus(1, ChronoUnit.WEEKS);

        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        System.out.println(date1.format(format));
    }
}
