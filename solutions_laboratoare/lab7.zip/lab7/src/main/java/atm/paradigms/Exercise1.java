package atm.paradigms;

import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class Exercise1 {
    public static void main(String[] args) throws InterruptedException, ExecutionException {
        CompletableFuture<String> futureString = CompletableFuture.supplyAsync(Exercise1::getMessage);
        CompletableFuture<Integer> futureInteger = CompletableFuture.supplyAsync(Exercise1::getNumber);
        System.out.println("String is: " + futureString.get());
        System.out.println("Integer is: " + futureInteger.get());
    }

    public static void sleep(int millis){
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static String getMessage(){
        sleep(2000);
        return "Hello World! ";
    }

    public static int getNumber(){
        sleep(1500);
        return new Random().nextInt();
    }
}
