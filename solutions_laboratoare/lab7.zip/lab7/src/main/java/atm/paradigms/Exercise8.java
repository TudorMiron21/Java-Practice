package atm.paradigms;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Exercise8 {
    public static void main(String[] args) {
        LocalDateTime dateTime = LocalDateTime.now();
        LocalDateTime modifiedDateTime = dateTime
                .withDayOfMonth(25)
                .withMonth(12)
                .withYear(2023);
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");
        System.out.println(modifiedDateTime.format(format));
    }
}
