package atm.paradigms;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import static java.util.stream.Collectors.toList;

public class Exercise4 {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(11, 45, 21, 56, 89, 34, 65, 77, 99, 3);
        List<CompletableFuture<Integer>> futures = list.stream()
                .map(n -> CompletableFuture.supplyAsync(() -> getNumber(n)))
                .map(f -> f.thenApply(n -> n * n))
                .collect(toList());
        futures.stream()
                .map(CompletableFuture::join)
                .forEach(System.out::println);
    }

    public static int getNumber(int n) {
        Exercise1.sleep(2000);
        return new Random().nextInt(100) * n;
    }
}
