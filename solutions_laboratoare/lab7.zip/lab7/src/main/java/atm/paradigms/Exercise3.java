package atm.paradigms;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class Exercise3 {
    public static void main(String[] args) throws InterruptedException, ExecutionException {
        CompletableFuture<String> futureString = CompletableFuture.supplyAsync(Exercise1::getMessage);
        CompletableFuture<Integer> futureInteger = CompletableFuture.supplyAsync(Exercise1::getNumber);
        CompletableFuture<String> futureConcat = futureString.thenCombine(futureInteger, (a, b) -> a + b);
        System.out.println("Main thread moves on. ");
        String res = futureConcat.get();
        System.out.println(res);
    }
}
