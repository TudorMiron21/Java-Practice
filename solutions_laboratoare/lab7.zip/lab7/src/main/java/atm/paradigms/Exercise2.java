package atm.paradigms;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class Exercise2 {
    public static void main(String[] args) throws InterruptedException, ExecutionException {
        CompletableFuture<String> futureString = CompletableFuture.supplyAsync(Exercise1::getMessage);
        CompletableFuture<String> futureConcat = futureString.thenApply((a) -> a + "said ASYNC");
        System.out.println(futureConcat.get());
    }
}
