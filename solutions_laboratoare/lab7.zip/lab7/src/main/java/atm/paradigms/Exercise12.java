package atm.paradigms;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.TimeZone;

public class Exercise12 {
    public static void main(String[] args) {
        ZoneId localZone = TimeZone.getDefault().toZoneId();
        LocalDateTime dateTime = LocalDateTime.now();
        ZonedDateTime zdt1 = dateTime.atZone(localZone);
        ZoneId tokyoZone = ZoneId.of("Asia/Tokyo");
        ZonedDateTime zdt2 = zdt1.withZoneSameInstant(tokyoZone);
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");
        System.out.println("Tokyo Now: " + zdt2.format(format));
    }
}
