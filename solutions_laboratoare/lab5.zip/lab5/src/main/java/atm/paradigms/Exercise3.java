package atm.paradigms;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class Exercise3 {
    public static void main(String[] args) {
        List<String> list = Arrays.asList("Java", "Scala", "C++", "Haskell", "Lisp");
        System.out.println("Words starting with J: ");
        filter(list, s -> s.startsWith("J"));
        System.out.println("Words ending with a: ");
        filter(list, s -> s.endsWith("a"));
        System.out.println("All words: ");
        filter(list, s -> true);
        System.out.println("No word: ");
        filter(list, s -> false);
    }

    private static void filter(List<String> list, Predicate<String> condition){
        for (String el : list){
            if (condition.test(el)){
                System.out.println(el + " ");
            }
        }
    }
}
