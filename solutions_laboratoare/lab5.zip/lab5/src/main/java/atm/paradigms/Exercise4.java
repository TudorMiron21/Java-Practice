package atm.paradigms;

import java.util.Arrays;
import java.util.List;

public class Exercise4 {
    public static void main(String[] args) {
        List<String> list = Arrays.asList("abc", "", "bcd", "", "defg", "jk");
        long count = list.stream()
                .filter(s -> !s.isEmpty())
                .count();
        System.out.println("Total: " + count);
    }
}
