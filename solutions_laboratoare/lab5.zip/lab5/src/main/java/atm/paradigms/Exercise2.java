package atm.paradigms;

public class Exercise2 {
    public static void main(String[] args) {
        String message =  "Java programming rules";
        Greetings grt1 = System.out::println;
        Greetings grt2 = m -> System.out.println("MESSAGE: " + m.toUpperCase());
        Greetings grt3 = m -> System.out.println("Message: " + m.toLowerCase());
        grt1.say(message);
        grt2.say(message);
        grt3.say(message);
    }
}
