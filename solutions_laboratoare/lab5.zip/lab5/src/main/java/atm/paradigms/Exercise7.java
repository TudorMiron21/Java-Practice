package atm.paradigms;

import java.util.Arrays;
import java.util.List;

public class Exercise7 {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(9, 10, 3, 4, 7, 3, 4);
        int sum = list.stream()
                .mapToInt(x -> x * x)
                .distinct()
                .sum();
        System.out.println("Sum: " + sum);
    }
}
