package atm.paradigms;

import java.util.Optional;
import java.util.stream.Stream;

public class Exercise10 {
    public static void main(String[] args) {
        Stream<String> stream = Stream.of("wsxa", "asdfg", "rfve", "bgfsr", "ertya", "yhnu", "mkower", "rtyu");
        Optional<String> opt = stream
                .map(String::toUpperCase)
                .filter(s -> s.startsWith("A") || s.startsWith("B"))
                .findFirst();
        System.out.println(opt.orElse("none"));
    }
}
