package atm.paradigms;

@FunctionalInterface
public interface Greetings {
    void say(String message);
}
