package atm.paradigms;

import java.util.stream.Stream;

public class Exercise11 {
    public static void main(String[] args) {
        Stream<String> stream = Stream.of("wsxa", "asdfg", "rfve", "bgfsr", "ertya", "yhnu", "mkower", "rtyu");
        boolean res = stream
                .distinct()
                .anyMatch(s -> s.length() > 4);
        if (res)
            System.out.println("There are words with more than 4 characters");

    }
}
