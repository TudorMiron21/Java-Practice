package atm.paradigms;

import java.util.List;
import java.util.stream.Stream;

public class Album {
    private String name;
    private List<Track> tracks;
    private List<Artist> nusicians;

    public Album(String name, List<Track> tracks, List<Artist> nusicians) {
        this.name = name;
        this.tracks = tracks;
        this.nusicians = nusicians;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Stream<Artist> getMusicians() {
        return this.nusicians.stream();
    }

    public Stream<Track> getTracks() {
        return this.tracks.stream();
    }
}
