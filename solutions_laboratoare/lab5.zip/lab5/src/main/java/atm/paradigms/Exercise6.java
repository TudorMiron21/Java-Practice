package atm.paradigms;

import java.util.Arrays;
import java.util.List;
import static java.util.stream.Collectors.toList;

public class Exercise6 {
    public static void main(String[] args) {
        List<String> list = Arrays.asList("aAA", "abcEEs", "xcvBNM", "edcTGB");
        List<String> upperCaseList = list.stream()
                .map(s -> s.toUpperCase())
                .collect(toList());
        System.out.println(upperCaseList);
    }
}
