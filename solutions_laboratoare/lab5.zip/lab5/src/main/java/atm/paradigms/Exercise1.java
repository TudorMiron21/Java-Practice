package atm.paradigms;

public class Exercise1 {
    public static void main(String[] args) {
        MathOperation sum = (a, b) -> a+ b;
        MathOperation subtract = (a, b) -> a - b;
        MathOperation product = (a, b) -> a * b;
        MathOperation division = (a, b) -> a / b;
        MathOperation remainder = (a, b) -> a % b;
        int a = 9, b= 2;
        System.out.println(a  + " + " + b + " = " + calculate(a, b, sum));
        System.out.println(a  + " - " + b + " = " + calculate(a, b, subtract));
        System.out.println(a  + " * " + b + " = " + calculate(a, b, product));
        System.out.println(a  + " / " + b + " = " + calculate(a, b, division));
        System.out.println(a  + " % " + b + " = " + calculate(a, b, remainder));
    }

    private static int calculate(int a, int b, MathOperation math){
        return math.operation(a, b);
    }
}
