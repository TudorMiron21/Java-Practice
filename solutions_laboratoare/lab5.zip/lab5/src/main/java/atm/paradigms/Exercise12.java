package atm.paradigms;

import java.util.Arrays;
import java.util.List;
import static java.util.stream.Collectors.toList;
import static java.util.Comparator.comparing;;

public class Exercise12 {
    public static void main(String[] args) {
        String name = "Billboard Top Country Hits";
        List<Track> tracks = Arrays.asList(
                new Track("The Battle of New Orleans"),
                new Track("Don't Take Your Guns to Town"),
                new Track("Billy Bayou"),
                new Track("El Paso"),
                new Track("One More Time"));
        List<Artist> nusicians = Arrays.asList(
                new Artist("Johnny Horton", "USA"),
                new Artist("Johnny Cash", "USA"),
                new Artist("Jim Reeves", "USA"),
                new Artist("Marty Robbins", "USA"),
                new Artist("Ray Price", "USA"));
        Album album = new Album(name, tracks, nusicians);
        List<String> upperCaseTracks = album.getTracks()
                .map(t -> t.getName().toUpperCase())
                .collect(toList());
        long countTracks = album.getTracks().count();
        System.out.println("Tracks: " + upperCaseTracks
                + "\nTotal tracks: " + countTracks);
        List<String> artists = album.getMusicians()
                .sorted(comparing(Artist::getName))
                .map(a -> a.getName())
                .collect(toList());
        System.out.println("Artists: " + artists);
    }
}
