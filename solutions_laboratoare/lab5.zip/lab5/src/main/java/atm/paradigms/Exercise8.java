package atm.paradigms;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import static java.util.stream.Collectors.toList;

public class Exercise8 {
    public static void main(String[] args) {
        Stream<List<Integer>> stream = Stream.of(
                Arrays.asList(1, 2),
                Arrays.asList(4, 6),
                Arrays.asList(8, 9));
        List<Integer> list = stream
                    .flatMap(l -> l.stream())
                    .limit(4)
                    .collect(toList());
        System.out.println(list);

    }
}
