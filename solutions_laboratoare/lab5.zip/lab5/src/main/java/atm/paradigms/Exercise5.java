package atm.paradigms;

import java.util.Arrays;
import java.util.List;
import static java.util.stream.Collectors.toList;

public class Exercise5 {
    public static void main(String[] args) {
        List<String> list = Arrays.asList("a", "b", "aA", "bB", "abc", "abcd", "fghjk", "zxcvbn", "x", "wsxedc");
        List<String> filtered = list.stream()
                .filter(s -> s.length() > 2)
                .collect(toList());
        System.out.println(filtered);
    }
}
