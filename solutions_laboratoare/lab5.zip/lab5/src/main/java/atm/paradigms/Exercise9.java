package atm.paradigms;

import java.util.stream.Stream;

public class Exercise9 {
    public static void main(String[] args) {
        int sum = Stream.iterate(0, n -> n + 2)
                .limit(20)
                .reduce(0, Integer::sum);
        System.out.println("Sum: " + sum);
    }
}
