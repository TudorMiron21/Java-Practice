package atm.paradigms;

import static java.util.stream.Collectors.joining;

public class Exercise5 {
    public static void main(String[] args) {
        String menu = Dish.getDishes().stream()
                .map(Dish::getName)
                .collect(joining(", "));
        System.out.println("Menu: " + menu);
    }
}
