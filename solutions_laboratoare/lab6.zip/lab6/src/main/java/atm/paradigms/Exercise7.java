package atm.paradigms;

import static java.util.stream.Collectors.groupingBy;

import java.util.List;
import java.util.Map;

public class Exercise7 {
    public static void main(String[] args) {
        Map<Type, List<Dish>> group = Dish.getDishes().stream()
                .collect(groupingBy(Dish::getType));
        System.out.println(group);
    }
}
