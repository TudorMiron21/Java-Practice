package atm.paradigms;

import static java.util.stream.Collectors.groupingBy;

import java.util.Map;

import static java.util.stream.Collectors.counting;

public class Exercise9 {
    public static void main(String[] args) {
        Map<Type, Long> countDishes = Dish.getDishes().stream()
                .collect(groupingBy(Dish::getType, counting()));
        System.out.println(countDishes);
    }
}
