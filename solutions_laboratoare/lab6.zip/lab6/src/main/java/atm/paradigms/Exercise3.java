package atm.paradigms;

import static java.util.stream.Collectors.summingInt;
import static java.util.stream.Collectors.averagingInt;

public class Exercise3 {
    public static void main(String[] args) {
        int totalCalories = Dish.getDishes().stream()
                .collect(summingInt(Dish::getCalories));
        double avgCalories = Dish.getDishes().stream()
                .collect(averagingInt(Dish::getCalories));
        System.out.println("Total calories: " + totalCalories
                + "\nAverage calories: " + avgCalories);
    }
}
