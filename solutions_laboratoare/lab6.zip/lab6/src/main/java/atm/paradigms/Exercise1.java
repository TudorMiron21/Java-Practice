package atm.paradigms;

import static java.util.stream.Collectors.counting;

public class Exercise1 {
    public static void main(String[] args) {
        Long countDishes = Dish.getDishes().stream()
                .collect(counting());
        System.out.println("Total dishes: " + countDishes);
    }
}
