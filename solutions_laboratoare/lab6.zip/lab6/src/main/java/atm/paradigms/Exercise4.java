package atm.paradigms;

import static java.util.stream.Collectors.summarizingInt;

import java.util.IntSummaryStatistics;

public class Exercise4 {
    public static void main(String[] args) {
        IntSummaryStatistics stats = Dish.getDishes().stream()
                .collect(summarizingInt(Dish::getCalories));
        System.out.println("Statistics: " + stats);
    }
}
