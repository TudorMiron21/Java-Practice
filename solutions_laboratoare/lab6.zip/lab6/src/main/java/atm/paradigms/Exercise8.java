package atm.paradigms;

import static java.util.stream.Collectors.groupingBy;
import java.util.List;
import java.util.Map;

public class Exercise8 {
    public static void main(String[] args) {
        Map<CaloricLevel, List<Dish>> groups = Dish.getDishes().stream()
                .collect(groupingBy(d -> {
                    if (d.getCalories() <= 400)
                        return CaloricLevel.DIET;
                    else if (d.getCalories() <= 700)
                        return CaloricLevel.NORMAL;
                    else
                        return CaloricLevel.FAT;
                }));
        System.out.println(groups);
    }
}
