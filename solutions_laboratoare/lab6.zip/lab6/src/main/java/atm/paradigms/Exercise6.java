package atm.paradigms;

import static java.util.stream.Collectors.reducing;

public class Exercise6 {
    public static void main(String[] args) {
        int totalCalories = Dish.getDishes().stream()
                .collect(reducing(0, Dish::getCalories, (a, b) -> a + b));
        System.out.println("Total calories: " + totalCalories);
    }
}
