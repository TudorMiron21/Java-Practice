package atm.paradigms;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.partitioningBy;

import java.util.List;
import java.util.Map;

public class Exercise10 {
    public static void main(String[] args) {
        Map<Boolean, Map<Type, List<Dish>>> clasify = Dish.getDishes().stream()
                .collect(partitioningBy(Dish::isVegetarian,
                        groupingBy(Dish::getType)));
        System.out.println(clasify);
    }
}
