package atm.paradigms;

import java.util.Comparator;
import java.util.Optional;

import static java.util.stream.Collectors.maxBy;
import static java.util.stream.Collectors.minBy;

public class Exercise2 {
    public static void main(String[] args) {
        Comparator<Dish> compCalories = Comparator.comparingInt(Dish::getCalories);
        Optional<Dish> maxCaloriesDish = Dish.getDishes().stream()
                .collect(maxBy(compCalories));
        Optional<Dish> minCaloriesDish = Dish.getDishes().stream()
                .collect(minBy(compCalories));
       maxCaloriesDish.ifPresent(System.out::println);
       minCaloriesDish.ifPresent(System.out::println);
    }
}
