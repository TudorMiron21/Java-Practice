package atm.paradigms;

public interface Animal {
    default void say(){
        System.out.println("Hello from default polite animal");
    }

    void bark();
}
