package atm.paradigms;

public class Exercise12 {
    public static void main(String[] args) {
        Dog dog = new Dog("Rex");
        dog.say();
        dog.bark();
    }
}
