package atm.paradigms;

public enum CaloricLevel {
    DIET, NORMAL, FAT
}
