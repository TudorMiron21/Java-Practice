package atm.paradigms;

public enum Type {
    MEAT, FISH, OTHER
}
