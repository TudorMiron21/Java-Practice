package atm.paradigms;

import java.util.function.Function;
import java.util.stream.LongStream;

public class Exercise11 {
    public static void main(String[] args) {
        System.out.println("Sequential time: " + measurePerformance(Exercise11::squareSumSequential, 10_000_000) + " ms");
        System.out.println("Parallel time: " + measurePerformance(Exercise11::squareSumParallel, 10_000_000) + " ms");
    }

    public static long measurePerformance(Function<Long, Long> adder, long n) {
        long fastest = Long.MAX_VALUE;
        for (int i = 0; i < 10; i++) {
            long start = System.nanoTime();
            long sum = adder.apply(n);
            long duration = (System.nanoTime() - start) / 1_000_000;
            System.out.println("Result: " + sum);
            if (duration < fastest)
                fastest = duration;
        }
        return fastest;
    }

    public static long squareSumSequential(long n) {
        return LongStream.rangeClosed(0, n)
                .map(x -> x * x)
                .reduce(0, Long::sum);
    }

    public static long squareSumParallel(long n) {
        return LongStream.rangeClosed(0, n)
                .parallel()
                .map(x -> x * x)
                .reduce(0, Long::sum);
    }
}
