package atm.paradigms;

import io.reactivex.Observable;

public class Exercise1 {
    public static void main(String[] args) {
        Observable<String> source = Observable.create(e -> {
            e.onNext("Aa");
            e.onNext("Bb");
            e.onNext("Cc");
            e.onNext("Dd");
            e.onNext("Ff");
            e.onNext("Gg");
            e.onNext("Hh");
            e.onComplete();
        });
        source.subscribe(System.out::println);
    }
}
