package atm.paradigms;

import io.reactivex.Single;

public class Exercise7 {
    public static void main(String[] args) {
        Single.just("java rules")
                .map(s -> s.toUpperCase())
                .subscribe(System.out::println, Throwable::printStackTrace);
    }
}
