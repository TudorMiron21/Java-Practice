package atm.paradigms;

import io.reactivex.Observable;

public class Exercise3 {
    public static void main(String[] args) {
        Observable<String> source = Observable.just("Aweeeee", "Bb", "abba", "ffffff", "Ghjk", "ALBANIA", "uuuuuu",
                "nnn");
        source.filter(s -> s.startsWith("a") || s.startsWith("A"))
                .subscribe(System.out::println);
    }
}
