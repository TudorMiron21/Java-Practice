package atm.paradigms;

import io.reactivex.Observable;

public class Exercise10 {
    public static void main(String[] args) {
        Observable.range(1, 100)
                .skip(80)
                .subscribe(System.out::println);
    }
}
