package atm.paradigms;

import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.observables.ConnectableObservable;

public class Exercise5 {
    public static void main(String[] args) {
        ConnectableObservable<Long> source = Observable.interval(1, TimeUnit.SECONDS).publish();
        source.subscribe(l -> System.out.println("Obs 1 got: " + l));
        source.connect();
        sleep(3000);
        source.subscribe(l -> System.out.println("Obs 2 got: " + l));
        sleep(3000);
    }

    private static void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
