package atm.paradigms;

import java.util.Arrays;
import java.util.List;

import io.reactivex.Observable;

public class Exercise6 {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(1, 3, 0, 2, 5, 8, 11, 0, 45, 88);
        Observable<Integer> source = Observable.fromIterable(list);
        source.map(x -> 1 / x).subscribe(System.out::println, Throwable::printStackTrace);
    }
}
