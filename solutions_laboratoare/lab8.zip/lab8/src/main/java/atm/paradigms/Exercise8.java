package atm.paradigms;

import io.reactivex.Observable;

public class Exercise8 {
    public static void main(String[] args) {
        Observable.range(1, 100)
                .takeWhile(i -> i < 10)
                .subscribe(System.out::println);
    }
}
