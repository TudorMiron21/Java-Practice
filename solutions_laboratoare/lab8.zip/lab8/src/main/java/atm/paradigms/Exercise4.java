package atm.paradigms;

import io.reactivex.Observable;

public class Exercise4 {
    public static void main(String[] args) {
        Observable<String> source = Observable.just("Aweeeee", "Bb", "abba", "ffffff", "Ghjk", "ALBANIA", "uuuuuu",
                "nnn");
        source.filter(s -> s.length() > 3)
                .subscribe(System.out::println,
                        Throwable::printStackTrace,
                        () -> System.out.println("Done!"));
    }
}
