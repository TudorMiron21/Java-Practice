package atm.paradigms;

import io.reactivex.Observable;

public class Exercise2 {
    public static void main(String[] args) {
        Observable<String> source = Observable.create(e -> {
            try {
                e.onNext("Aa");
                e.onNext("Bb");
                e.onNext("Cccccccc");
                e.onNext("Dd");
                e.onNext("Ffjjjjjjjjj");
                e.onNext("Gg");
                e.onNext("Hh");
                e.onComplete();
            } catch (Throwable err) {
                e.onError(err);
            }
        });
        Observable<Integer> filteredSource = source
                .map(w -> w.length())
                .filter(l -> l >= 4);
        filteredSource.subscribe(System.out::println);
    }
}
