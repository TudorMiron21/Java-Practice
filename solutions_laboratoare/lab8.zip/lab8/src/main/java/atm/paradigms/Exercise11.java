package atm.paradigms;

import java.util.List;

import io.reactivex.Observable;

public class Exercise11 {
    public static void main(String[] args) {
        List<String> list = List.of("Aa", "Bb", "Cc", "Dd", "Ee", "Ff", "Gg", "Hh");
        Observable.fromIterable(list)
                .zipWith(Observable.range(1, 100), (s, i) -> String.format("%2d. %s", i, s))
                .subscribe(System.out::println);
    }
}
