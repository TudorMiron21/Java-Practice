package atm.paradigms;

import io.reactivex.Observable;

public class Exercise9 {
    public static void main(String[] args) {
        Observable.just("aA", "bB", "Cc", "Dd", "eE", "gG", "Hh")
                .filter(s -> s.startsWith("Z"))
                .switchIfEmpty(Observable.just("Zz", "Xx", "yY"))
                .subscribe(System.out::println);
    }
}
