package atm.paradigms;

import java.util.HashMap;
import java.util.Map;

public class Exercise14 {
    public static void main(String[] args) {
        Map<Integer,String> hm= new HashMap<Integer,String>(); 
        hm.put(1,"Red");
        hm.put(2,"Green");
        hm.put(3,"Black");
        hm.put(4,"White");
        hm.put(5,"Blue"); 
        System.out.println("Value for 2 is " + hm.get(2));
        System.out.println("Value for 3 is " + hm.get(3));
    }
}
