package atm.paradigms;

import java.util.ArrayList;
import java.util.List;

public class Exercise2 {
    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>();
        list.add(21);
        list.add(35);
        list.add(46);
        list.add(58);
        list.add(9);
        list.add(78);
        list.add(81);
        list.add(99);
        for (int i : list){
            System.out.println(i);
        }
    }
}
