package atm.paradigms;

public class Square {
    private int side;
    private String color;

    public Square(int side, String color) {
        this.side = side;
        this.color = color;
    }

    public int getSide() {
        return side;
    }

    public void setSide(int side) {
        this.side = side;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Double getArea(){
        return (double) (side * side);
    }

    @Override
    public String toString() {
        return "Square [side=" + side + ", color=" + color + "]";
    }
    
    
}
