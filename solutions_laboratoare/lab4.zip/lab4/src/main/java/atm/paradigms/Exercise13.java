package atm.paradigms;

import java.util.TreeSet;

public class Exercise13 {
    public static void main(String[] args) {
        TreeSet<Integer> ts = new TreeSet<>();
        ts.add(10);
        ts.add(22);
        ts.add(37);
        ts.add(26);
        ts.add(13);
        ts.add(71);
        ts.add(85);
        ts.add(93);
        ts.add(7);
        ts.add(47);
        System.out.println("Original: " + ts);
        System.out.println("Less than or equal to 50: " + ts.floor(50));
        System.out.println("First: " + ts.pollFirst());
        System.out.println("Final: " + ts);
    }
}
