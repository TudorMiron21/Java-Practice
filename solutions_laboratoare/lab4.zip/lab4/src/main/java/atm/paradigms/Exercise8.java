package atm.paradigms;

import java.util.LinkedList;

public class Exercise8 {
    public static void main(String[] args) {
        LinkedList<String> l_list = new LinkedList<String>();
        l_list.add("Red");
        l_list.add("Green");
        l_list.add("Black");
        l_list.add("Pink");
        l_list.add("Orange");
        System.out.println("List: " + l_list);
        String first = l_list.getFirst();
        String last = l_list.getLast();
        System.out.println("First: " + first 
                            + "\nLast: " + last);
    }
}
