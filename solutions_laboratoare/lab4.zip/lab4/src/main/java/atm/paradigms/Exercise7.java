package atm.paradigms;

import java.util.LinkedList;

public class Exercise7 {
    public static void main(String[] args) {
        LinkedList<String> l_list = new LinkedList<String>();
        l_list.add("Red");
        l_list.add("Green");
        l_list.add("Black");
        System.out.println("Original:" + l_list);
        l_list.addFirst("Gray");
        l_list.offerFirst("Yellow");
        l_list.addLast("Pink");
        l_list.offerLast("Black");
        System.out.println("Final:" + l_list);
        System.out.println("First element: " + l_list.getFirst());
        System.out.println("Last element: " + l_list.getLast());
    }
}
