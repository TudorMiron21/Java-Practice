package atm.paradigms;

import java.util.Comparator;

public class SquareComp implements Comparator<Square> {

    @Override
    public int compare(Square o1, Square o2) {
        return o1.getArea().compareTo(o2.getArea());     
    }
}
