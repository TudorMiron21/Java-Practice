package atm.paradigms;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Exercise4 {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("edf");
        list.add("ggg");
        list.add("hhh");
        list.add("Aaa");
        list.add("iii");
        list.add("aaA");
        list.add("ddd");    
        list.add("bbb");
        list.add("bBb");
        list.add("cba");
        list.add("ccc");
        System.out.println(list);
        // natural order sorting
        Collections.sort(list);
        System.out.println(list);
    }
}
