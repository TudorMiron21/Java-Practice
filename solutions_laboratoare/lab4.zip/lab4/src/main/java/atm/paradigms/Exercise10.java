package atm.paradigms;

import java.util.TreeSet;

public class Exercise10 {
    public static void main(String[] args) {
        TreeSet<String> ts = new TreeSet<String>();
        ts.add("White");
        ts.add("Black");
        ts.add("Red");
        ts.add("Green");
        ts.add("Orange");
        System.out.println("Original: " + ts);
        String first = ts.first();
        String last = ts.last();
        System.out.println("First: " + first
                + "\nLast: " + last);
    }
}
