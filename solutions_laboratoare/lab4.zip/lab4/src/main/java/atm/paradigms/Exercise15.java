package atm.paradigms;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Exercise15 {
    public static void main(String[] args) {
        List<Circle> list = Arrays.asList(
            new Circle(1, Color.BLUE),
            new Circle(2, Color.GREEN),
            new Circle(3, Color.RED),
            new Circle(4, Color.YELLOW),
            new Circle(5, Color.GREEN)
            );
        Iterator<Circle> iter = list.iterator();
        while (iter.hasNext()){
            printColor(iter.next().getColor());
        }
    }

    private static void printColor(Color color) {
        switch (color) {
            case BLUE:
                System.out.println("Circle is blue");
                break;
            case GREEN:
                System.out.println("Circle is green");
                break;
            case RED:
                System.out.println("Circle is red");
                break;
            case YELLOW:
                System.out.println("Circle is red");
                break;
            default:
                System.out.println("Unknown color");
        }
    }
}
