package atm.paradigms;

public enum Color {
    RED,
    BLUE,
    YELLOW,
    GREEN
}
