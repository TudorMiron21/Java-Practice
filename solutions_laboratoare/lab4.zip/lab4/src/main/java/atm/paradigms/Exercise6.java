package atm.paradigms;

import java.util.Iterator;
import java.util.LinkedList;


public class Exercise6 {
    public static void main(String[] args) {
        LinkedList<String> l_list = new LinkedList<>();
        l_list.add("aA");
        l_list.add("Bb");
        l_list.add("cc");
        l_list.add("dd");
        l_list.add("Dd");
        l_list.add("ee");
        l_list.add("FF");
        l_list.add("ss");
        System.out.println("Orginal: " + l_list);
        Iterator<String> it = l_list.descendingIterator();
        System.out.println("Reversed: ");
        while (it.hasNext()){
            System.out.print(it.next() + " ");
        }
        System.out.println();
    }
}
