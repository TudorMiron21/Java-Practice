package atm.paradigms;

import java.util.ArrayList;
import java.util.List;

public class Exercise1 {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("Red");
        list.add("Yellow");
        list.add("Green");
        list.add("White");
        list.add("Blue");
        list.add("Magenta");
        list.add("Black");
        list.add("Pink");
        System.out.println(list);
    }
}
