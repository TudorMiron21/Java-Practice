package atm.paradigms;

import java.util.ArrayList;
import java.util.List;

public class Exercise5 {
    public static void main(String[] args) {
        List<String> list = new ArrayList<String>();
        list.add("Red");
        list.add("Green");
        list.add("Orange");
        list.add("White");
        list.add("Black");
        String color = "Orange";
        if (list.contains(color)) {
            int idx = 0;
            // iteration
            for (String el : list) {
                if (el.equals(color)) {
                    System.out.println("First way: " + idx);
                    break;
                }
                idx++;
            }
            // indexOf()
            System.out.println("Second way: " + list.indexOf(color));
        } else
            System.out.println("No such element in list.");
    }
}
