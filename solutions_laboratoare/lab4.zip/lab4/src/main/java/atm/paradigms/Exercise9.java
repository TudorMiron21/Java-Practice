package atm.paradigms;

import java.util.Collections;
import java.util.LinkedList;

public class Exercise9 {
    public static void main(String[] args) {
        LinkedList<String> l_list = new LinkedList<String>();
        l_list.add("Red");
        l_list.add("Green");
        l_list.add("Black");
        l_list.add("Pink");
        l_list.add("Orange");
        System.out.println("Original: " + l_list);
        Collections.shuffle(l_list);
        System.out.println("Final: " + l_list);
    }
}
