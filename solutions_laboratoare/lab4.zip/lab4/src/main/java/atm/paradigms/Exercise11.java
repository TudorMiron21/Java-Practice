package atm.paradigms;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Exercise11 {
    public static void main(String[] args) {
        Map<Integer, String> hm = new HashMap<Integer, String>();
        hm.put(1, "Red");
        hm.put(2, "Green");
        hm.put(3, "Black");
        hm.put(4, "White");
        hm.put(5, "Blue");
        hm.put(6, "Yellow");
        hm.put(7, "Magenta");
        hm.put(8, "Gray");
        hm.put(9, "Brown");
        hm.put(10, "Orange");
        Set<Map.Entry<Integer, String>> set = hm.entrySet();
        for (Map.Entry<Integer, String> el : set) {
            System.out.println("(" + el.getKey() + ": "
                    + el.getValue() + ")");
        }
    }
}
