package atm.paradigms;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Exercise12 {
    public static void main(String[] args) {
        SquareComp comp = new SquareComp();
        List<Square> list = Arrays.asList(
            new Square(3, "black"),
            new Square(2, "white"),
            new Square(1, "green"),
            new Square(4, "blue"),
            new Square(1, "red")
        );
        System.out.println("Original: " + list);
        Collections.sort(list, comp);
        System.out.println("Final: " + list);
    }
}
