package atm.paradisms;

import java.util.List;
import java.util.stream.Collectors;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("ex3")
public class Exercise3 {
    @POST
    @Path("people")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public List<Human> addPeople(Human human) {
        List<Human> list = Tools.getPeople();
        List<Human> localList = list.stream()
                .collect(Collectors.toList());
        if (human.getId() == 0)
            human.setId(list.size() + 1);
        localList.add(human);
        return localList;
    }
}
