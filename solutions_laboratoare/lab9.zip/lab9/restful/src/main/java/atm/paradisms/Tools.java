package atm.paradisms;

import java.util.Arrays;
import java.util.List;

public class Tools {
    public static List<Human> getPeople(){
        return Arrays.asList(
            new Human(1, "Traian", 55, 'M'),
            new Human(2, "Catalin", 45, 'M'),
            new Human(3, "Maria", 27, 'F'),
            new Human(4, "Elena", 19, 'F'),
            new Human(5, "Marius", 47, 'M')
        );
    }
}
