package atm.paradigms;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Exercise4 {
    public static void main(String[] args) {
        ObjectMapper om = new ObjectMapper();
        Circle circle = new Circle(10, "GRAY");
        try(OutputStream output = new FileOutputStream("circleOut.json")){
            om.writeValue(output, circle);
        } catch (IOException e ){
            e.printStackTrace();
        }
    }
}
