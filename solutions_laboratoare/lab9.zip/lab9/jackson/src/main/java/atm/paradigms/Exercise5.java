package atm.paradigms;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class Exercise5 {
    public static void main(String[] args) {
        ObjectMapper om = new ObjectMapper();
        ObjectNode node = om.createObjectNode();
        node.put("id", 1);
        node.put("name", " John");
        node.put("email", "john@atm.ro");
        node.put("faculty", "FSISC");
        node.put("yearOfStudy", 3);
        try(OutputStream output = new FileOutputStream("studentOut.json")){
            om.writeValue(output, node);
        } catch (IOException e ){
            e.printStackTrace();
        }
    }
}
