package atm.paradigms;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Exercise3 {
    public static void main(String[] args) {
        try (InputStream input = Exercise2.class.getResourceAsStream("circleArray.json")){
            ObjectMapper om = new ObjectMapper();
            List<Circle> circleList = om.readValue(input, new TypeReference<List<Circle>>() {});
            System.out.println(circleList);
        } catch (IOException e){
            e.printStackTrace();
        }
    }
}
