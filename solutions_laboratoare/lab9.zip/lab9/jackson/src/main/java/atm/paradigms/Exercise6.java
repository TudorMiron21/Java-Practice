package atm.paradigms;

import java.io.IOException;
import java.io.InputStream;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class Exercise6 {
    public static void main(String[] args) throws IOException {
        InputStream input = Exercise6.class.getResourceAsStream("circle.json");
        ObjectMapper om = new ObjectMapper();
        JsonNode root = om.readTree(input);
        ((ObjectNode)root).put("color","BLACK");
        System.out.println(root);
    }
}
