package atm.paradigms;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Exercise1 {
    public static void main(String[] args) throws JsonMappingException, JsonProcessingException {
        ObjectMapper om = new ObjectMapper();
        String json = "{\"radius\":3,\"color\":\"BLACK\"}";
        Circle circle = om.readValue(json, Circle.class);
        System.out.println(circle);
    }
}
