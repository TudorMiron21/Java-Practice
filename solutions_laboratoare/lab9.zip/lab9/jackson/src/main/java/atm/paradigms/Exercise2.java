package atm.paradigms;

import java.io.IOException;
import java.io.InputStream;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Exercise2 {
    public static void main(String[] args) {
        try (InputStream input = Exercise2.class.getResourceAsStream("circle.json")){
            ObjectMapper om = new ObjectMapper();
            Circle circle = om.readValue(input, Circle.class);
            System.out.println(circle);
        } catch (IOException e){
            e.printStackTrace();
        }
    }
}
