package atm.paradigms;

public class TemperatureException extends Exception{
    public TemperatureException(String message){
        super(message);
    } 
}
