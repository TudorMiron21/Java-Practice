package atm.paradigms;

public class Exercise2 {
    public static void main(String[] args) {
        try{
            int[] a = new int[5];
            a[5] = 6;
        } catch (ArrayIndexOutOfBoundsException e){
            System.out.println("Error: " + e.getMessage());
        }
    }
}
