package atm.paradigms;

public class Exercise3 {
        public static void main(String[] args) {
                Circle circle = new Circle(2.0);
                circle.setColor("red");
                System.out.println("\tCircle\nColor: " + circle.getColor()
                                + "\nArea: " + circle.getArea()
                                + "\nPerimeter: " + circle.getPerimeter());
                System.out.println(circle);

                Rectangle rectangle = new Rectangle(4.0, 2.0);
                rectangle.setColor("green");
                System.out.println("\tRectangle\nColor: " + rectangle.getColor()
                                + "\nArea: " + rectangle.getArea()
                                + "\nPerimeter: " + rectangle.getPerimeter());
                System.out.println(rectangle);

                Square square = new Square(5.0);
                square.setColor("blue");
                System.out.println("\tSquare\nColor: " + square.getColor()
                                + "\nArea: " + square.getArea()
                                + "\nPerimeter: " + square.getPerimeter());
                System.out.println(square);

        }
}
