package atm.paradigms;

public class Exercise1 {
    public static void main(String[] args) {
        Author author1 = new Author("Marin Preda", "marin.preda@gmail.com", 'm');
        Book book1 = new Book("Morometzii", author1, 61.80);
        book1.setQty(100);
        Author author2 = new Author("Marin Preda", "marin.preda@gmail.com", 'm');
        Book book2 = new Book("Viata ca o prada", author2, 61.80, 200);
        System.out.println(book1);
        System.out.println(book2);
        // extra
        System.out.println(Author.getCount());
    }
}
