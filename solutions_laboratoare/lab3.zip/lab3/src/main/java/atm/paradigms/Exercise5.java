package atm.paradigms;

public class Exercise5 {
    public static void main(String[] args) {
        Movable point = new MovablePoint(5, 5, 1, 1);
        point.moveUp();
        point.moveRight();
        point.moveDown();
        point.moveDown();
        point.moveLeft();
        point.moveLeft();
        System.out.println(point);
    }
}
