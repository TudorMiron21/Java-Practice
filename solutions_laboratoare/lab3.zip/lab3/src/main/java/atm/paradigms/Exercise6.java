package atm.paradigms;

import java.util.Scanner;

public class Exercise6 {
    public static void main(String[] args) {
        try {
            Scanner s = new Scanner(System.in);
            int t = Integer.valueOf(s.nextLine());
            s.close();
            if (t >= 40)
                throw new TemperatureException("Esti foarte bolnav!");
        } catch (NumberFormatException e) {
            e.printStackTrace();
        } catch (TemperatureException e) {
            System.out.println("Mesaj eroare: " + e.getMessage());
        }
    }
}
