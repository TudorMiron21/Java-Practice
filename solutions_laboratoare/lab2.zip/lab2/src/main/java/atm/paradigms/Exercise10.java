package atm.paradigms;

public class Exercise10 {
    public static void main(String[] args) {
        int my_array[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        int sum = 0;

        for (int i : my_array)
            sum += i;
        System.out.println("Suma: " + sum);
        System.out.println("Media: " + ((double)sum/my_array.length));
    }
}
