package atm.paradigms;

public class Exercise1 {
    public static void main(String[] args) {
        double d1 = 5.0, d2 = 3.0;
        System.out.println("Suma: " + (d1 + d2));
        int i1 = 10, i2 = 3;
        System.out.println("Impartire: " + (i1 / i2));
        System.out.println("Modulo: " + (i1 % i2));
        char ch = (char) 89;
        System.out.println("Conversie la char: " + --ch);
    }
}
