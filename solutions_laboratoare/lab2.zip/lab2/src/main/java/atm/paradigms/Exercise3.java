package atm.paradigms;

public class Exercise3 {
    public static void main(String[] args) {
        int chr = 'A';
        System.out.println("Codul ASCII: " + chr);
    }
}
