package atm.paradigms;

public class Exercise12 {
    public static void main(String[] args) {
        int array1[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int array2[] = new int[array1.length];
        int i = 0;
        for (int val : array1){
            array2[i] = val;
            i++;
        }
        for (int val : array1)
            System.out.print(val + " ");
    }
}
