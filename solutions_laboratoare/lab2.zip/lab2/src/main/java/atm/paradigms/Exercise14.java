package atm.paradigms;

public class Exercise14 {
    public static void main(String[] args) {
        String str = "Java programming language";
        System.out.println("Primul indece: " + str.indexOf("g"));
        System.out.println("Ultimul indece: " + str.lastIndexOf("g"));
        System.out.println("Cracter la 10: " + str.charAt(10));
    }
}
