package atm.paradigms;

public class Exercise9 {
    public static void main(String[] args) {
        Circle c1 = new Circle();
        System.out.println("Raza: " + c1.getRadius() 
                             + "\nAria: " + c1.getArea()
                             + "\nPerimetrul: " + c1.getCircumference());  
                             
        Circle c2 = new Circle(3.0);
        System.out.println("Raza: " + c2.getRadius() 
        + "\nAria: " + c2.getArea()
        + "\nPerimetrul: " + c2.getCircumference());  
    }
}
