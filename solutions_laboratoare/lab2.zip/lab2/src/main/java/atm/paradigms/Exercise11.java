package atm.paradigms;

public class Exercise11 {
    public static void main(String[] args) {
        Date d1 = new Date(1, 12, 2022);
        d1.setDay(25);
        d1.setMonth(10);
        System.out.println("Year: " + d1.getYear());
        System.out.println("Data: " + d1);
        Date d2 = new Date(31, 12, 2022);
        System.out.println("Day: " + d2.getDay());
        d2.setMonth(1);
        d2.setYear(2023);
        System.out.println("Data: " + d2);
    }
}
