package atm.paradigms;

public class Exercise4 {
    public static void main(String[] args) {
        double radius = 5.0;
        double perimeter = 2 * Math.PI * radius;
        double area = Math.PI * radius * radius;

        System.out.println("Perimetrul este: " + perimeter);
        System.out.println("Area este:  " + area);
    }
}
