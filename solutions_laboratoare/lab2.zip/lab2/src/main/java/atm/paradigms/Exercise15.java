package atm.paradigms;

public class Exercise15 {
    public static void main(String[] args) {
        String s1 = "abcdef";
        String s2 = "cdef";
        int res = s1.compareTo(s2);
        if (res < 0)
            System.out.println("s1 este mai mic decat s2");
        else if (res == 0)
            System.out.println("s1 este egal cu s2");
        else
            System.out.println("s1 este mai mare decat s2");
    }
}
