package atm.paradigms;

public class Exercise6 {
    public static void main(String[] args) {
        int n1 = 7;
        int n2 =11;
        if (n1 != n2)
            System.out.println(n1 + " este diferit de " + n2);
        if (n1 < n2){
            System.out.println(n1 + " este mai mic decat " + n2);
        } else if ( n1 > n2) {
            System.out.println(n1 + " este mai mare decat " + n2);
        } else 
            System.out.println(n1 + " este egal cu " + n2);
    }
}
