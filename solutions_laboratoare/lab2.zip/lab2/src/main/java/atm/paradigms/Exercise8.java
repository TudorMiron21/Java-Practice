package atm.paradigms;

public class Exercise8 {
    public static void main(String[] args) {
        int n = 256;
        int sum = 0;
        while (n != 0){
            sum += n % 10;
            n /= 10;
        }
        System.out.println("Suma cifrelor: " + sum);
    }
}
