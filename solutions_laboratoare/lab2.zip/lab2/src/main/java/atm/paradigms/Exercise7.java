package atm.paradigms;

public class Exercise7 {
    public static void main(String[] args) {
        double a = 0.9;
        double b = 2.3;
        System.out.println(a > 0 && a < 1 && b > 0 && b < 1);
    }
}
