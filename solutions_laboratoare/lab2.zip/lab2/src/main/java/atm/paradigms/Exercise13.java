package atm.paradigms;

public class Exercise13 {
    public static void main(String[] args) {
        String s1 = "abcDEf";
        String s2 = "gHijKLMnop";
        s1 = s1.toUpperCase();
        s2 = s2.toLowerCase();
        String res = s1.concat(s2);
        System.out.println(res);
        System.out.println("Length: " + res.length());
    }
}
