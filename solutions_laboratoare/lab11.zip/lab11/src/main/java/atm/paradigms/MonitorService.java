package atm.paradigms;

import javax.enterprise.event.Observes;
import javax.inject.Inject;
import javax.inject.Singleton;

import org.jboss.logging.Logger;

import atm.paradigms.model.Employee;

@Singleton
public class MonitorService {
    @Inject
    Logger logger;

    public void requestEvent(@Observes Employee employee){
        logger.info(employee);
    }
}
