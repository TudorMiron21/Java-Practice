package atm.paradigms;

import java.util.List;
import java.util.Optional;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Event;
import javax.inject.Inject;

import atm.paradigms.model.Employee;
import atm.paradigms.utils.Tools;

@ApplicationScoped
public class EmployeesService {
    @Inject
    Event<Employee> empRequestEvt;

    @Inject
    DefaultEmployee defaultEmployee;

    public List<Employee> getEmployees() {
        return Tools.getPeople();
    }

    public Employee getEmplyeeById(int id) {
        List<Employee> list = Tools.getPeople();
        Optional<Employee> optEmp = list.stream()
                .filter(e -> e.getId() == id)
                .findFirst();
        Employee employee = optEmp.orElse(defaultEmployee.getInstance());
        empRequestEvt.fire(employee);
        return employee;
    }
}
