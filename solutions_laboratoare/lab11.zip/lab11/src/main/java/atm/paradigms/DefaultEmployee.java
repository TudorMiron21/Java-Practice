package atm.paradigms;

import javax.enterprise.context.ApplicationScoped;

import org.eclipse.microprofile.config.inject.ConfigProperty;

import atm.paradigms.model.Employee;

@ApplicationScoped
public class DefaultEmployee {
    @ConfigProperty(name = "employee.id")
    private int id;
    @ConfigProperty(name = "employee.name")
    private String name;
    @ConfigProperty(name = "employee.department")
    private String department;
    @ConfigProperty(name = "employee.age")
    private int age;

    public Employee getInstance(){
        return new Employee(id, name, department, age);
    };
}
