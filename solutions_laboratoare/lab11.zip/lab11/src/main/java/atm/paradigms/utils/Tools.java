package atm.paradigms.utils;

import java.util.Arrays;
import java.util.List;

import atm.paradigms.model.Employee;

public class Tools {
    public static List<Employee> getPeople(){
        return Arrays.asList(
            new Employee(1, "Costel", "IT", 35),
            new Employee(2, "Alina", "IT", 26),
            new Employee(3, "Ioana", "HR", 46),
            new Employee(4, "Marius", "Customer ", 32),
            new Employee(5, "Mihai", "Sales ", 23)
        );
    }
}
