package atm.paradigms.others;

public enum Stages {
    CHILD, TEENAGER, ADULT
}
