package atm.paradigms.datetime;
import java.time.*;
import java.util.TimeZone;

public class NewDateTest {
    public static void main(String[] args) {
        ZoneId localZone = TimeZone.getDefault().toZoneId();
        System.out.println(localZone);
        LocalDateTime dt = LocalDateTime.of(2022, Month.SEPTEMBER, 12, 14, 30);
        ZonedDateTime zdt1 = dt.atZone(localZone);
        ZonedDateTime zdt2 = zdt1.withZoneSameInstant(ZoneId.of("Europe/Rome"));
        System.out.println(zdt2);

        Instant instant = Instant.now();
        LocalDateTime timeFromInstant = LocalDateTime.ofInstant(instant, ZoneId.of("Europe/Rome"));
        System.out.println(timeFromInstant);
        timeFromInstant = LocalDateTime.ofInstant(instant, ZoneId.of("Europe/London"));
        System.out.println(timeFromInstant);
    }
}
