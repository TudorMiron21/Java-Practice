package atm.paradigms.async;

public class Discount {

    private static String apply(double price, Code code){
        Shop.delay();
        return String.format("%.2f", price * (100 - code.getPercentage())/100);
    }

    public static String discount(Quote quote){
        return quote.getShopName() + " price is "
                    + apply(quote.getPrice(), quote.getDiscountCode());
    }
}
