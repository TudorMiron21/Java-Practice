
package atm.paradigms.others;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static java.util.stream.Collectors.*;
import static java.util.Comparator.*;

public class Population {
    public static void main(String[] args) {
        List<Person> population = populate();
        // List<String> threeOver40 = population.stream()
        // .filter(p -> {
        // System.out.println("filtering " + p.getName());
        // return p.getAge() > 40;
        // })
        // .map(p -> {
        // System.out.println("mapping " + p.getName());
        // return p.getName();
        // })
        // .limit(3)
        // .collect(toList());
        // System.out.println(threeOver40);
        Map<Boolean, Person> olderPartitionedByEmployed = population.stream().collect(
                partitioningBy(Person::isEmployed,
                        collectingAndThen(
                                maxBy(comparingInt(Person::getAge)),
                                Optional::get)));
        System.out.println(olderPartitionedByEmployed);

    }

    public static List<Person> populate() {
        return Arrays.asList(
                new Person("Ion", true, 46, Person.Gender.MALE),
                new Person("Maria", false, 15, Person.Gender.FEMALE),
                new Person("Vasile", false, 25, Person.Gender.MALE),
                new Person("Violeta", true, 50, Person.Gender.FEMALE),
                new Person("Marius", false, 5, Person.Gender.MALE),
                new Person("Alexia", true, 35, Person.Gender.FEMALE),
                new Person("George", true, 28, Person.Gender.MALE),
                new Person("Cristina", false, 19, Person.Gender.FEMALE),
                new Person("Mihai", true, 55, Person.Gender.MALE));
    }
}
