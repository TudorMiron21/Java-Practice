package atm.paradigms.async;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import static java.util.stream.Collectors.*;

public class AsyncTest {

    public static void main(String[] args) throws InterruptedException {

        long start = System.nanoTime();
        // System.out.println(findPricesBlocking("laptop"));
        // System.out.println(findPricesParrallel("laptop"));
       // System.out.println(findPricesAsync("laptop"));
        System.out.println(findPricesAsyncInEUR("laptop"));
        System.out.println("Done in "
                + (System.nanoTime() - start) / 1_000_000 + "ms");

    }

    private static Executor getExecutor() {
        return Executors.newFixedThreadPool(Math.min(getShopList().size(), 100),
                new ThreadFactory() {
                    @Override
                    public Thread newThread(Runnable r) {
                        Thread t = new Thread(r);
                        // don't prevent termination of program
                        t.setDaemon(true);
                        return t;
                    }
                });
    }

    public static List<Shop> getShopList() {
        return Arrays.asList(new Shop("eMag"),
                new Shop("Altex"),
                new Shop("Flanco"));
    }

    public static List<String> findPricesBlocking(String product) {
        return getShopList().stream()
                .map(shop -> shop.getPrice(product))
                .map(Quote::parse)
                .map(Discount::discount)
                .collect(toList());
    }

    public static List<String> findPricesParrallel(String product) {
        return getShopList().parallelStream()
                .map(shop -> String.format("%s is %.2f",
                        shop.getName(), shop.getPrice(product)))
                .collect(toList());
    }

    public static List<String> findPricesAsync(String product) {
        List<CompletableFuture<String>> futurePrices = getShopList().stream()
                .map(shop -> CompletableFuture.supplyAsync(
                        () -> shop.getPrice(product), getExecutor()))
                .map(future -> future.thenApply(Quote::parse))
                .map(future -> future.thenCompose(quote -> CompletableFuture.supplyAsync(
                        () -> Discount.discount(quote))))
                .collect(toList());
        return futurePrices.stream()
                .map(CompletableFuture::join)
                .collect(toList());
    }

    public static List<Double> findPricesAsyncInEUR(String product) {
        List<CompletableFuture<Double>> futurePrices = getShopList().stream()
                .map(shop -> CompletableFuture.supplyAsync(
                        () -> shop.getPrice(product), getExecutor()))
                .map(future -> future.thenApply(Quote::parse))
                .map(future -> future.thenApply(Quote::getPrice))
                .map(future -> future.thenCombine(
                        CompletableFuture.supplyAsync(
                                () -> ExchangeService.getRate(Money.RON, Money.EUR)),
                        (price, rate) -> price * rate))
                .collect(toList());
        return futurePrices.stream()
                .map(CompletableFuture::join)
                .collect(toList());
    }
}
