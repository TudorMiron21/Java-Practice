package atm.paradigms.book;

public class BookTest {
    public static void main(String[] args) {
        BookE books[] = new BookE[3];
        books[0] = new BookE("Java: A Beginner's Guide",
                "Schildt", 2005, "O'Reilly");
        books[1] = new BookE("Java: The Complete Reference",
                "Schildt", 2005, "O'Reilly");
        books[2] = new BookE("The Art of Java",
                "Schildt and Holmes", 2003, "O'Reilly");
        for (int i = 0; i < books.length; i++)
            books[i].show();
    }
}
