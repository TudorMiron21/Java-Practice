package atm.paradigms.async;

public class ExchangeService {
    public static double getRate(Money src, Money dest){
        Shop.delay();
        return dest.getRate() / src.getRate();
    }
}
