package atm.paradigms.async;

import java.util.concurrent.*;

public class FutureTest {
    public static void main(String[] args) {
        ExecutorService executor = Executors.newCachedThreadPool();
        Future<Long> future = executor.submit(new Callable<Long>(){
            @Override
            public Long call() throws Exception {
                return doLongComputation();
            }
        });
        try {
            doSomethingElse();
            Long result = future.get(6, TimeUnit.SECONDS);
            System.out.println("Got result: " + result);
            System.exit(0);
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            e.printStackTrace();
        }
    }

    public static long doLongComputation() throws InterruptedException{
        Thread.sleep(5000);
        System.out.println("Long task done!");
        return 5L;
    }
    public static void doSomethingElse() throws InterruptedException{
        Thread.sleep(2000);
        System.out.println("Something else done!");
    }
}
