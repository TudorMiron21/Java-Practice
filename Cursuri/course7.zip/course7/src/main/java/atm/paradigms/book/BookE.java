package atm.paradigms.book;

public class BookE extends Book {
    private String publisher;

    public BookE(String title, String author, int year, String publisher) {
        super(title, author, year);
        this.publisher = publisher;
    }

    @Override
    public void show() {
        super.show();
        System.out.println(this.publisher);
        System.out.println();
    }

    @Override
    public String toString() {
        return super.title + " " +  super.author ;
    }
}
