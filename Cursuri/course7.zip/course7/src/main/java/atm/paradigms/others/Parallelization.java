package atm.paradigms.others;

import java.util.function.Function;
import java.util.stream.LongStream;
import java.util.stream.Stream;

public class Parallelization {
    public static void main(String[] args) {
        // System.out.println("Sequentual sum: "
        //      + measurePerformance(Parallelization::sequentialSum, 10_000_000) + " ms");
        // System.out.println("Iterative sum: "
        //      + measurePerformance(Parallelization::iterativeSum, 10_000_000) + " ms");
        // System.out.println("Parallel sum: "
        //      + measurePerformance(Parallelization::parallelSum, 10_000_000) + " ms");
        System.out.println("Parallel sum: "
        + measurePerformance(Parallelization::parallelRangedSum, 100_000_000) + " ms");
    }

    public static long rangedSum(long n){
        return LongStream.rangeClosed(1, n)
                        .reduce(0L, Long::sum);
    }

    public static long parallelRangedSum(long n){
        return LongStream.rangeClosed(1, n)
                        .parallel()
                        .reduce(0L, Long::sum);
    }

    public static long measurePerformance(Function<Long, Long> adder, long n){
        long fastest = Long.MAX_VALUE;
        for (int i = 0; i < 10; i++){
            long start = System.nanoTime();
            long sum = adder.apply(n);
            long duration = (System.nanoTime() - start)/1_1000_000;
            System.out.println("Result: " + sum);
            if (duration < fastest) fastest = duration;
        }
        return fastest;
    }

    public static long parallelSum(long n){
        return Stream.iterate(1L, i -> i+ 1)
        .limit(n)
        .parallel() // turn tu paralel stream
        .reduce(0L, Long::sum);
    }

    public static long sequentialSum(long n){
        return Stream.iterate(1L, i -> i+ 1)
        .limit(n)
        .reduce(0L, Long::sum);
    }

    public static long iterativeSum(long n){
        long result = 0;
        for (long i = 1L; i <= n; i++){
            result += i;
        }
        return result;
    }
}
