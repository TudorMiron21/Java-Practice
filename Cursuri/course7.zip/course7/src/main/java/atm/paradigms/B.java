package atm.paradigms;

public class B extends A {
    public static void main(String[] args) {
        int var[] = new int[10];
        System.out.println(var[100]);
    }

    @Override
    public void show() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'show'");
    }

}
