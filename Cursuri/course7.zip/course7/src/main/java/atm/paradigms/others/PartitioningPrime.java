package atm.paradigms.others;

import java.util.*;
import java.util.stream.IntStream;
import static java.util.stream.Collectors.*;

public class PartitioningPrime {

    public static void main(String[] args) {
        Map<Boolean, List<Integer>> primes = partitionPrime(29);
        System.out.println(primes);
    }

    private static boolean isPrime(int candidate){
        // factors less then or equal with the square root
        int root = (int) Math.sqrt(candidate);
        return IntStream.rangeClosed(2, root)
            .noneMatch(i -> candidate % i == 0);
    }
    public static Map<Boolean, List<Integer>> partitionPrime(int n){
        return IntStream.rangeClosed(2, n).boxed()
        .collect(partitioningBy(c -> isPrime(c)));
    }
}
