package atm.paradigms.async;

public enum Money {
    EUR(1.0), RON(4.86), USD(0.99), GBP(0.86);
    private final double rate;

    Money(double rate) {
        this.rate = rate;
    }
    public double getRate() {
        return rate;
    }
}
