package atm.paradigms.others;
import java.util.function.DoubleUnaryOperator;

public class Currying {
    public static void main(String[] args) {
        DoubleUnaryOperator convertC2F = curriedConverter(9.0/5, 32);
        System.out.println("Celsius to Fahrenheit: " + convertC2F.applyAsDouble(40));
        DoubleUnaryOperator convertKm2MI = curriedConverter(0.6214, 0);
        System.out.println("Kilometers to Miles:" + convertKm2MI.applyAsDouble(100));
    }

    public static DoubleUnaryOperator curriedConverter(double f, double b){
        return x -> x * f + b;
    }
}
