package atm.paradigms.others;

public class Person {
    private final String name;
    private final boolean employed;
    private final int age;
    private final Gender gender;

    public Person(String name, boolean employed, int age, Gender gender) {
        this.name = name;
        this.employed = employed;
        this.age = age;
        this.gender = gender;
    }

    public String getName() {
        return name;
    }
    public boolean isEmployed() {
        return employed;
    }
    public int getAge() {
        return age;
    }
    public Gender getGender() {
        return gender;
    }

    @Override
    public String toString() {
        return name;
    }

    public enum Gender {MALE, FEMALE};
}
