package atm.paradigms;

public abstract class A {
    private int a;

    public A() {
        this.a = 100;
    }

    public int getA() {
        return a;
    }

    abstract public void show();

}
