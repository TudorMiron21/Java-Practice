package atm.paradigms.others;

public class TrainJourney {
    public int price;
    public TrainJourney onward;

    public static void main(String[] args) {
        TrainJourney tj1 = new TrainJourney(40, new TrainJourney(30, null));
        TrainJourney tj2 = new TrainJourney(20, new TrainJourney(50, null));
        append(tj1, tj2);
        System.out.print(tj1);
    }

    public TrainJourney(int p, TrainJourney t) {
        price = p;
        onward = t;
    }

    public static TrainJourney append(TrainJourney a, TrainJourney b){
        return a == null ? b : new TrainJourney(a.price, append(a.onward, b));
    }


    public static TrainJourney link(TrainJourney a, TrainJourney b) {
        if (a == null)
            return b;
        TrainJourney t = a;
        while (t.onward != null) {
            t = t.onward;
        }
        t.onward = b;
        return a;
    }

    @Override
    public String toString() {
        return "TrainJourney [onward=" + onward + ", price=" + price + "]";
    }


}
