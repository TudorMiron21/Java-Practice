package atm.paradigms.async;

import java.util.Random;

public class Shop {
    private final String name;
    private final Random random = new Random();

    public Shop(String name) {
        this.name = name;
    }

    public String getPrice(String product){
        double price  = calculatePrice(product);
        Code code = Code.values()[random.nextInt(Code.values().length)];
        return name + ":" + price + ":" + code;
    }

    public static void delay(){
        try {
            Thread.sleep(2000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    private double calculatePrice(String product){
        delay();
        return  random.nextDouble() * product.charAt(0)
                    + product.charAt(1);
    }

    public String getName() {
        return name;
    }
}
