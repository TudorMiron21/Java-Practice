package atm.paradigms.others;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class DefaultMethods {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(3, 5, 7, 2, 1, 4);
        numbers.sort(Comparator.naturalOrder());
        System.out.println(numbers);
    }
}
