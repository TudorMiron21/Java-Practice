package atm.paradigms;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class ArtistResourceIT extends ArtistResourceTest {
    // Execute the same tests but in packaged mode.
}
