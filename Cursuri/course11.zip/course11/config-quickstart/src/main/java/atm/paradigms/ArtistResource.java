package atm.paradigms;

import java.util.List;
import java.util.UUID;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import atm.paradigms.model.Artist;

@Path("/artists")
public class ArtistResource {
    private static List<Artist> artists = List.of(
        new Artist(UUID.randomUUID(), "John", "Lennon"),
        new Artist(UUID.randomUUID(), "Paul", "McCartney"),
        new Artist(UUID.randomUUID(), "george", "Harrison"),
        new Artist(UUID.randomUUID(), "Ringo", "Starr")
    );

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllArtists(){
        return Response.ok().entity(artists).build();
    }

    @GET
    @Path("/count")
    @Produces(MediaType.TEXT_PLAIN)
    public Integer countArtists(){
        return artists.size();
    }
}