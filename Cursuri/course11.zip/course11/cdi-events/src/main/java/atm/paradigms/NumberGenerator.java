package atm.paradigms;

public interface NumberGenerator {
    String generateNumber();
}
