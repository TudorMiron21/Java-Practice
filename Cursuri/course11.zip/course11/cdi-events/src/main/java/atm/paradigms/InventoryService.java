package atm.paradigms;

import java.util.ArrayList;
import java.util.List;


import javax.enterprise.event.Observes;
import javax.inject.Inject;
import javax.inject.Singleton;

import org.jboss.logging.Logger;

import atm.paradigms.model.Book;

@Singleton
public class InventoryService {
    @Inject
    Logger logger;

    List<Book> inventory = new ArrayList<>();

    public void addBook(@Observes @Added Book book){
       logger.info("Adding book " + book.getTitle() + " to inventory");
       inventory.add(book);
    }
}
