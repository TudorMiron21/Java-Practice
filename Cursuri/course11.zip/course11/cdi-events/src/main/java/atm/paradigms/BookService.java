package atm.paradigms;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Event;
import javax.inject.Inject;

import atm.paradigms.model.Book;

@ApplicationScoped
public class BookService {
   @Inject
   NumberGenerator numberGenerator;
   
   @Inject @Added
   Event<Book> bookAddedEvt;

    public Book createBook(String title, Float price, String description){
        Book book = new Book(title, price, description);
        book.setIsbn(numberGenerator.generateNumber());
        bookAddedEvt.fire(book);
        return book;
    }
}
