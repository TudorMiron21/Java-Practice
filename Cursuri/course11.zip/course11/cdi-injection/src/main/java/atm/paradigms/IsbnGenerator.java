package atm.paradigms;
import java.util.Random;
import javax.enterprise.context.ApplicationScoped;

@ThirteenDigits
@ApplicationScoped
public class IsbnGenerator implements NumberGenerator{
    @Override
    public String generateNumber() {
        return "13-84356-" + Math.abs(new Random().nextInt());
    }
}
