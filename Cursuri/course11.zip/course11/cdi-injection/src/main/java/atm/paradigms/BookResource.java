package atm.paradigms;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import atm.paradigms.model.Book;

@Path("book")

public class BookResource {
    @Inject
    BookService bookService;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getBook(){
        Book book = bookService.createBook("Morometii", 56.88F, "About contrymen");
        return Response.ok(book).build();
    } 
}
