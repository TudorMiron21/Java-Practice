package atm.paradigms;
import java.util.Random;
import javax.enterprise.context.ApplicationScoped;

@EightDigits
@ApplicationScoped
public class IssnGenerator implements NumberGenerator {
    @Override
    public String generateNumber() {
        return "8-" + Math.abs(new Random().nextInt());
    }
}
