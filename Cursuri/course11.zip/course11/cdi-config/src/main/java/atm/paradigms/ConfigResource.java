package atm.paradigms;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.jboss.logging.Logger;

@Path("config")
public class ConfigResource {
    @Inject
    Logger logger;

    @Inject
    Invoice invoice;
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getInvoice(){
        logger.info(invoice);
        return invoice.toString();
    }
}
