package atm.paradigms;

import javax.inject.Singleton;

import org.eclipse.microprofile.config.inject.ConfigProperty;

@Singleton
public class InvoiceYaml {
    Float subtotal;
    @ConfigProperty(name = "app.invoice.vatRate", defaultValue = "10")
    Float vatRate;
    Float vatAmount;
    Float total;
    @ConfigProperty(name = "app.invoice.allowsDiscount", defaultValue = "true")
    Boolean allowsDiscount;
    @ConfigProperty(name = "app.invoice.discountRate", defaultValue = "2.5")
    Float discountRate;
    @ConfigProperty(name = "app.invoice.terms")
    String terms;
    @ConfigProperty(name = "app.invoice.penalties")
    String penalties;
    @Override

    public String toString() {
        return "InvoiceYaml [subtotal=" + subtotal + ", vatRate=" + vatRate + ", vatAmount=" + vatAmount + ", total="
                + total + ", allowsDiscount=" + allowsDiscount + ", discountRate=" + discountRate + ", terms=" + terms
                + ", penalties=" + penalties + "]";
    }  
}
