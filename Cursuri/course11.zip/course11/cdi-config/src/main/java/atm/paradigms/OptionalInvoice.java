package atm.paradigms;

import java.util.Optional;

import javax.inject.Singleton;

import org.eclipse.microprofile.config.inject.ConfigProperty;

@Singleton
public class OptionalInvoice {
    Float subtotal = 0.0F;
    @ConfigProperty(name = "invoice.vatRate", defaultValue = "10")
    Float vatRate;
    Float vatAmount = 0.0F;
    Float total = 0.0F;
    @ConfigProperty(name = "invoice.allowsDiscount", defaultValue = "true")
    Boolean allowsDiscount;
    @ConfigProperty(name = "invoice.discountRate", defaultValue = "2.5")
    Float discountRate;
    @ConfigProperty(name = "invoice.terms")
    Optional<String> terms;
    @ConfigProperty(name = "invoice.penalties")
    Optional<String> penalties;

    @Override
    public String toString() {
        return "OptionalInvoice [subtotal=" + subtotal + ", vatRate=" + vatRate + ", vatAmount=" + vatAmount
                + ", total=" + total + ", allowsDiscount=" + allowsDiscount + ", discountRate=" + discountRate
                + ", terms=" + terms + ", penalties=" + penalties + "]";
    }
}
