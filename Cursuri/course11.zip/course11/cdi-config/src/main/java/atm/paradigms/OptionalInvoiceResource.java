package atm.paradigms;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.jboss.logging.Logger;

@Path("optconfig")
public class OptionalInvoiceResource {
    @Inject
    Logger logger;

    @Inject
    OptionalInvoice optionalInvoice;

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public OptionalInvoice getConfig(){
        logger.info(optionalInvoice.toString());
        return optionalInvoice;
    }
}
