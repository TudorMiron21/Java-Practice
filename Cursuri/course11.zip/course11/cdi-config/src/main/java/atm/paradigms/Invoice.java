package atm.paradigms;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import org.eclipse.microprofile.config.inject.ConfigProperty;

@ApplicationScoped
public class Invoice {
    Float subtotal;
    @Inject
    @ConfigProperty(defaultValue = "10")
    Float vatRate;
    Float vatAmount;
    Float total;
    @Inject
    @ConfigProperty(defaultValue = "true")
    Boolean allowsDiscount;
    @Inject
    @ConfigProperty(defaultValue = "2.5")
    Float discountRate;
    @Inject
    @ConfigProperty
    String terms;
    @Inject
    @ConfigProperty
    String penalties;

    @Override
    public String toString() {
        return "Invoice [subtotal=" + subtotal + ", vatRate=" + vatRate + ", vatAmount=" + vatAmount + ", total="
                + total + ", allowsDiscount=" + allowsDiscount + ", discountRate=" + discountRate + ", terms=" + terms
                + ", penalties=" + penalties + "]";
    }
}
