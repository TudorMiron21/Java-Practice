package atm.paradigms;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class ReaderExample {
    private static final Logger logger =
            Logger.getLogger(ReaderExample.class.getName());
    public static void main(String[] args) throws IOException {
        logger.setLevel(Level.INFO);
        findAndUpdateNode("emp-array.json");
    }

    public static void findAndUpdateNode(String file) throws IOException{
        InputStream input = ReaderExample.class.getResourceAsStream(file);
        // create ObjectMapper instance
        ObjectMapper objMapper = new ObjectMapper();
        //read JSON like DOM Parser
        JsonNode rootNode = objMapper.readTree(input);
        if (rootNode.isArray()){
            for (JsonNode node : rootNode){
                System.out.println(node);
                JsonNode id = node.path("employeeId");
                logger.log(Level.INFO, "id-{0}", id.asInt());
                JsonNode email = node.path("email");
                logger.log(Level.INFO, "email = {0}", email.textValue());
                if (email.textValue() == null){
                    ((ObjectNode)node).put("email", "unknown");
                }
            }
            objMapper.writeValue(new File("emp-array-modified.json"), rootNode);
        }
    }
}
