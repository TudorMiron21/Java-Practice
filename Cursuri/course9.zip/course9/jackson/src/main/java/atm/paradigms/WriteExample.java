package atm.paradigms;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class WriteExample {
    private static final Logger logger = Logger.getLogger(WriteExample.class.getName());
    public static void main(String[] args) throws StreamReadException, DatabindException, IOException {
        logger.setLevel(Level.INFO);
        String fileName = "emp-array-modified.json";
        writeEmployeeList(fileName);
        logger.log(Level.INFO,"{0} written successfully.",fileName);
    }
    public static void writeEmployeeList(String file) throws StreamReadException, DatabindException, IOException{
        List<Employee> employees = getEmployeeList();
        ObjectMapper om = new ObjectMapper();
        try(OutputStream os = new FileOutputStream(file)){
            om.writeValue(os, employees);
        }
    }
    private static List<Employee> getEmployeeList() throws StreamReadException, DatabindException, IOException{
        return BindingExample.getEmployeeList("emp-array.json");
    }
}
