package atm.paradigms;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class CreateNodeExample {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        JsonNode user = generate();
        ObjectMapper om = new ObjectMapper();
        try(OutputStream os = new FileOutputStream("createdNode.json")){
            om.writeValue(os, user);
        }
    }

    public static JsonNode generate(){
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode user = mapper.createObjectNode();
        user.put("id", 1);
        user.put("name", "John Doe");
        user.put("email", "john.doe@example.com");
        user.put("salary", 3545.99);
        user.put("role", "QA Engineer");
        user.put("admin", false);
        // create a child JSON object
        ObjectNode address = mapper.createObjectNode();
        address.put("street", "2389  Radford Street");
        address.put("city", "Horton");
        address.put("state", "KS");
        address.put("zipCode", 66439);
        // append address to user
        user.set("address", address);
        return user;
    }
}
