package atm.paradigms;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;

public class BindingExample {
    private static final Logger logger = Logger.getLogger(BindingExample.class.getName());

    public static void main(String[] args) throws StreamReadException, DatabindException, IOException {
        logger.setLevel(Level.INFO);
        List<Employee> staff = getEmployeeList("emp-array.json");
        System.out.println(staff);

        String jsonString = "{\"employeeId\":100,\"firstName\":\"John\",\"lastName\":\"Chen\"}";
        System.out.println(getSimpleBinding(jsonString));

        Employee emp = getEmployee();
        logger.log(Level.INFO,"Employee: {0} read successfully.", emp);
    }

    public static List<Employee> getEmployeeList(String file)
            throws StreamReadException, DatabindException, IOException {
        InputStream input = ReaderExample.class.getResourceAsStream(file);
        // create ObjectMapper instance
        ObjectMapper objMapper = new ObjectMapper();
        CollectionType collection = objMapper.getTypeFactory().constructCollectionType(List.class, Employee.class);
        List<Employee> result = objMapper.readValue(input, collection);
        return result;
    }

    public static Map<String, String> getSimpleBinding(String json)
            throws JsonMappingException, JsonProcessingException {
        ObjectMapper om = new ObjectMapper();
        Map<String, String> result = om.readValue(json, new TypeReference<Map<String, String>>() {
        });
        return result;
    }

    public static Employee getEmployee() throws StreamReadException, DatabindException, IOException{
        InputStream input = ReaderExample.class.getResourceAsStream("emp.json");
        // create ObjectMapper instance
        ObjectMapper objMapper = new ObjectMapper();
        return objMapper.readValue(input, Employee.class);
    }

}
