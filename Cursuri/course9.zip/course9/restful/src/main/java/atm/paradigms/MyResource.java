package atm.paradigms;
import java.util.concurrent.ThreadLocalRandom;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("myresource")
public class MyResource {
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getIt() {
        return "Got it!";
    }

    @GET
    @Path("rand")
    @Produces("text/plain")
    public Integer getRand(){
        return ThreadLocalRandom.current().nextInt();
    }

    @DELETE
    @Path("object/{id}")
    @Produces("text/plain")
    public String getId(@PathParam("id") int id){
        return "You wanted me to delete ID: " + id;
    }

    @GET
    @Path("test/{param1}/{param2}")
    @Produces(MediaType.APPLICATION_JSON)
    public String getParams(@PathParam("param1") String p1,
                              @PathParam("param2") String p2){
        ObjectMapper objMapper = new ObjectMapper();
        ObjectNode root = objMapper.createObjectNode();
        root.put("Param1", p1);
        root.put("Param2", p2);
        return root.toString();
    }

    @GET
    @Path("test")
    @Produces(MediaType.APPLICATION_JSON)
    public String getQueryParams(@QueryParam("param1") String p1, 
                                 @QueryParam("param2") String p2){
        ObjectMapper objMapper = new ObjectMapper();
        ObjectNode root = objMapper.createObjectNode();
        root.put("QueryParam1", p1);
        root.put("QueryParam2", p2);
        return root.toString();
    }

    @POST
    @Path("test")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public String getFormParams(@FormParam("param1") String p1, 
                                @FormParam("param2") String p2){
        ObjectMapper objMapper = new ObjectMapper();
        ObjectNode root = objMapper.createObjectNode();
        root.put("FormParam1", p1);
        root.put("FormParam2", p2);
        return root.toString();
    }

    @GET
    @Path("test/{name}")
    @Produces(MediaType.APPLICATION_JSON)
    public String getContext(@Context UriInfo uriInfo){
        String name = uriInfo.getPathParameters().getFirst("name");
        ObjectMapper objMapper = new ObjectMapper();
        ObjectNode node = objMapper.createObjectNode();
        node.put("NameParam", name);
        return node.toString();
    }

}
