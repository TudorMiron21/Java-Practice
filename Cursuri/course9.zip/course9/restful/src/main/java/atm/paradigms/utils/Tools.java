package atm.paradigms.utils;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;

import atm.paradigms.model.Student;

public class Tools {
    public static List<Student> getStudents() throws StreamReadException, DatabindException, IOException{
        InputStream input = Tools.class.getResourceAsStream("/students.json");
         // create ObjectMapper instance
        ObjectMapper objMapper = new ObjectMapper();
        CollectionType collection = objMapper.getTypeFactory()
                                    .constructCollectionType(List.class, Student.class);
        List<Student> result = objMapper.readValue(input, collection);
         return result;
    }
}
