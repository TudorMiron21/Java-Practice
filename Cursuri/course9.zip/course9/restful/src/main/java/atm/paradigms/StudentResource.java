package atm.paradigms;

import java.io.IOException;
import java.util.List;
import static java.util.stream.Collectors.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;

import atm.paradigms.model.Student;
import atm.paradigms.utils.Tools;

@Path("atm")
public class StudentResource {
    @GET
    @Path("student")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getStudents() throws StreamReadException, DatabindException, IOException {
        List<Student> students = Tools.getStudents();
        // Sets cache control directive to the response
        CacheControl cacheControl = new CacheControl();
        // Cache the result for a day
        cacheControl.setMaxAge(86400);
        return Response.ok().cacheControl(cacheControl)
                .entity(students).build();
    }

    @PUT
    @Path("student/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public List<Student> addStudent(@PathParam("id") int id, Student student)
            throws StreamReadException, DatabindException, IOException {
        List<Student> students = Tools.getStudents();
        long count = students.stream()
                .filter(s -> s.getId() == id)
                .count();
        if (count == 0L) {
            student.setId(id);
            List<Student> copyStudents = students.stream()
                    .collect(toList());
            copyStudents.add(student);
            return copyStudents;
        } else {
            return students.stream()
                    .map(s -> {
                        if (s.getId() == id) {
                            s.setName(student.getName());
                            s.setFaculty(student.getFaculty());
                            s.setYearOfStudy(student.getYearOfStudy());
                        }
                        return s;
                    })
                    .collect(toList());
        }
    }

    @DELETE
    @Path("student/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Student> deleteStudent(@PathParam("id") int id)
            throws StreamReadException, DatabindException, IOException {
        List<Student> students = Tools.getStudents();
        return students.stream()
                .filter(s -> s.getId() != id)
                .collect(toList());
    }

    @GET
    @Path("student/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    // @Produces(MediaType.APPLICATION_XML)
    public Student getStudent(@PathParam("id") int id) {
        return new Student(id, "Ion Popescu", "FSISC", 3);
    }

    @POST
    @Path("student")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Student echoRequest(Student student) {
        student.setId(999);
        return student;
    }

}
