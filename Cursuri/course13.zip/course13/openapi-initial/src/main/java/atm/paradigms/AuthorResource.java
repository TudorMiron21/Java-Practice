package atm.paradigms;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;

@Path("authors")
@Produces(MediaType.APPLICATION_JSON)
public class AuthorResource {
    String[] scifiAuthors = { "Isaac Asimov", "Nora Jemisin", "Douglas Adams" };

    @GET
    @Path("{idx}")
    @Operation(summary = "Returns an author for a given index")
    @APIResponse(responseCode = "204", description = "Author not found")
    @APIResponse(responseCode = "200", description = "Author returned for a given index")
    public String getAuthor(@PathParam("idx") int idx) {
        return scifiAuthors[idx];
    }
}
