package atm.paradigms;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Arrays;
import java.util.HashSet;

import org.eclipse.microprofile.jwt.Claims;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import io.smallrye.jwt.build.Jwt;

@QuarkusTest
public class GenerateToken {
     /**
     * Generate JWT token
     */
    @Test
    public void gettUserAdminToken() {
        String token = Jwt.issuer("https://example.com/issuer")
                .upn("jdoe@quarkus.io")
                .groups(new HashSet<>(Arrays.asList("User", "Admin")))
                .claim(Claims.birthdate.name(), "2001-07-13")
                .sign();
        System.out.println("User Admin:\n\n" + token);
        assertNotNull(token);
    }

    @Test
    public void gettAdminToken() {
        String token = Jwt.issuer("https://example.com/issuer")
                .upn("jdoe@quarkus.io")
                .groups("Admin")
                .claim(Claims.birthdate.name(), "2001-07-13")
                .sign();
        System.out.println("Admin:\n\n" + token);
        assertNotNull(token);
    }

    @Test
    public void gettUserToken() {
        String token = Jwt.issuer("https://example.com/issuer")
                .upn("jdoe@quarkus.io")
                .groups("User")
                .claim(Claims.birthdate.name(), "2001-07-13")
                .sign();
        System.out.println("User:\n\n" + token);
        assertNotNull(token);
    }
}
