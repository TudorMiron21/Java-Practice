package atm.paradigms;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class TokenSecuredResourceIT extends TokenSecuredResourceTest {

    // Execute the same tests but in native mode.
}
