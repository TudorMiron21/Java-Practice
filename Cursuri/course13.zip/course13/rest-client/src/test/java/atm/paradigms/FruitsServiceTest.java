package atm.paradigms;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Set;

import javax.inject.Inject;

import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import atm.paradigms.model.Fruit;
import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class FruitsServiceTest {
    @Inject
    @RestClient
    FruitsService fruitsService;

    @Test
    @Order(1)
    void shouldGetAllFruits(){
        Set<Fruit> fruits = fruitsService.getAllFruits();
        assertEquals(5, fruits.size());
    }

    @Test
    @Order(2)
    void shouldGetOneFruit(){
        Fruit fruit = fruitsService.getFruitById(1);
        assertNotNull(fruit);
    }

    @Test
    @Order(3)
    void shouldAddNewFruit(){
        Fruit fruit = new Fruit();
        fruit.setName("Mango");
        fruit = fruitsService.addFruit(fruit);
        assertNotNull(fruit.getId());
    }

    @Test
    @Order(4)
    void shouldUpdateFruit(){
        Fruit fruit = new Fruit();
        fruit.setName("Fig");
        fruit = fruitsService.updateFruit(1, fruit);
        assertNotNull(fruit.getId());
    }

    @Test
    @Order(5)
    void shouldDeleteFruit(){
        fruitsService.deleteFruit(1);
        Set<Fruit> fruits = fruitsService.getAllFruits();
        assertEquals(5, fruits.size());
    }
}
