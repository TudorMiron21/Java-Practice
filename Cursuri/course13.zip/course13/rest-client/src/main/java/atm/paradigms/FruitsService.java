package atm.paradigms;

import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import atm.paradigms.model.Fruit;

import java.util.Set;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@RegisterRestClient(baseUri = "http://localhost:8080/")
public interface FruitsService {

    @GET
    @Path("fruits")
    Set<Fruit> getAllFruits();

    @GET
    @Path("fruits/{id}")
    Fruit getFruitById(@PathParam("id") long id);

    @POST
    @Path("fruits")
    Fruit addFruit(Fruit fruit);

    @PUT
    @Path("fruits/{id}")
    Fruit updateFruit(@PathParam("id") long id, Fruit fruit);

    @DELETE
    @Path("fruits/{id}")
    void deleteFruit(@PathParam("id") long id);
}
