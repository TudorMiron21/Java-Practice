package atm.paradigms.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

@Entity
@Table(name = "known_fruits")
public class Fruit extends PanacheEntityBase{
    @Id
    // avoid PRIMARY KEY violation
    @SequenceGenerator(name = "fruitsSequence", sequenceName = "hibernate_sequence", allocationSize = 1, initialValue = 10)
    @GeneratedValue(generator = "fruitsSequence")
    public Long id;
    
    @Column(length = 40, unique = true)
    public String name;
}
