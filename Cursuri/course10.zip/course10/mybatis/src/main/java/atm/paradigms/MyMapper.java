package atm.paradigms;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import atm.paradigms.model.Book;

public interface MyMapper {
    @Select("SELECT VERSION()")
    public String getMySQLVersion();

    @Select("SELECT * FROM MyBooks WHERE Id = #{id}")
    public Book getBookById(Long id);

    @Select("SELECT * FROM MyBooks WHERE Author = #{author}")
    public List<Book> getBooksByAuthor(String author);

    @Insert("INSERT INTO MyBooks(Author, Title, Published, Remark) "
            + "VALUES(#{author}, #{title}, #{published}, #{remark})")
    public void insertBook(String author, String title, int published,
            String remark);

    @Delete("DELETE FROM MyBooks WHERE Id = #{id}")
    public void deleteBookById(Long id);

    @Update("UPDATE MyBooks SET Author=#{author}, Title=#{title}, "
           + "Published=#{published}, Remark=#{remark} WHERE Id = #{id}")
    public void updateBook(Book book);
}
