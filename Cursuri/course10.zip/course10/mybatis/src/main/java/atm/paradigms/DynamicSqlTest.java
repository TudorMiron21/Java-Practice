package atm.paradigms;

import java.io.IOException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import atm.paradigms.model.Book;
import atm.paradigms.utils.Tools;

public class DynamicSqlTest {
    public static void main(String[] args) throws IOException {
        SqlSessionFactory  factory = Tools.getSqlSessionFactory();
        try (SqlSession session = factory.openSession();){
            Book book = session.selectOne("getBook", 1);
            System.out.println(book);
            List<Book> books = session.selectList("getBook");
            books.forEach(System.out::println);
        }
    }
}
