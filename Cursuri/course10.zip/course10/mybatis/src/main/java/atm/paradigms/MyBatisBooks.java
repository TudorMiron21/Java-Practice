package atm.paradigms;

import java.io.IOException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import atm.paradigms.model.Book;
import atm.paradigms.utils.Tools;

public class MyBatisBooks  {
    public static void main(String[] args) throws IOException {
        SqlSessionFactory factory = Tools.getSqlSessionFactory();
        try (SqlSession session = factory.openSession();){
            // select one book by Id
            Book book = session.selectOne("getBookById", 4L);
            System.out.println(book);
            // select books by authors
            List<Book> books = session.selectList("getBooksByAuthor", "Leo Tolstoy");
            books.forEach(System.out::println);
            // insert a new book
            Book newBook = new Book("Miguel de Cervantes", "Don Quixote", 1605, "First modern novel");
            session.insert("insertBook", newBook);
            // delete book by Id
            session.delete("deleteBookById", 8L);
            // update book by Id
            book.setAuthor("Lev Tolstoi");
            session.update("updateBook", book);
            session.commit();
            session.close();
        }
    }
}
