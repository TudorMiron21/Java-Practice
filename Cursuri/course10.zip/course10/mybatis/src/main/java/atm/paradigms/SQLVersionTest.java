package atm.paradigms;
import java.io.IOException;
import java.io.Reader;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class SQLVersionTest {
    private static SqlSessionFactory factory = null;
    public static void main(String[] args) throws IOException {
        String resource = "mybatis-config.xml";
        Reader reader = null;
        reader = Resources.getResourceAsReader(resource);
        factory = new SqlSessionFactoryBuilder().build(reader);
        factory.getConfiguration().addMapper(MyMapper.class);
        reader.close();
        try (SqlSession session = factory.openSession();){
            // method with annotation from interface
            String version = session.selectOne("getMySQLVersion");
            System.out.println(version);
            // mapping with xml file
            String version1 = session.selectOne("mysqlVersion");
            System.out.println(version1);
        }
    }
}
