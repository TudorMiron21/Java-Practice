package atm.paradigms;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import atm.paradigms.model.Book;
import atm.paradigms.utils.Tools;

@Path("book")
public class BooksService {
    private static final Logger logger = Logger.getLogger(BooksService.class.getName());

    @PermitAll
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllBooks(){
        try {
            SqlSessionFactory factory = Tools.getSqlSessionFactory(); 
            try(SqlSession session = factory.openSession();){
                List<Book> books = session.selectList("getBooks");
                return Response.ok().entity(books).build();
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.toString());
            ObjectMapper om = new ObjectMapper();
            ObjectNode node = om.createObjectNode();
            node.put("message", "An error occured. Check on server.");
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(node.toString()).build();
        }
    }

    @PermitAll
    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getABooksById(@PathParam("id") long id){
        try {
            SqlSessionFactory factory = Tools.getSqlSessionFactory(); 
            try(SqlSession session = factory.openSession();){
                Book book = session.selectOne("getBookById", id);
                return Response.ok().entity(book).build();
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.toString());
            ObjectMapper om = new ObjectMapper();
            ObjectNode node = om.createObjectNode();
            node.put("message", "An error occured. Check on server.");
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(node.toString()).build();
        }
    }
    
    @RolesAllowed("ADMIN")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
    public Response addBook(Book book){
        ObjectMapper om = new ObjectMapper();
        try {
            SqlSessionFactory factory = Tools.getSqlSessionFactory(); 
            try(SqlSession session = factory.openSession();){
                session.insert("insertBook", book);
                session.commit();
                ObjectNode node = om.createObjectNode();
                node.put("message", "Book successfully inserted.");
                return Response.status(Status.CREATED).entity(node.toPrettyString()).build();
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.toString());
            ObjectNode node = om.createObjectNode();
            node.put("message", "An error occured. Check on server.");
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(node.toString()).build();
        }       
    }

    @RolesAllowed("ADMIN")
    @PUT
    @Path("{id}")
    @Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
    public Response modifyBook(@PathParam("id") long id, Book book){
        ObjectMapper om = new ObjectMapper();
        try {
            SqlSessionFactory factory = Tools.getSqlSessionFactory(); 
            try(SqlSession session = factory.openSession();){
                book.setId(id);
                session.update("updateBook", book);
                session.commit();
                ObjectNode node = om.createObjectNode();
                node.put("message", "Book successfully updated.");
                return Response.status(Status.CREATED).entity(node.toPrettyString()).build();
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.toString());
            ObjectNode node = om.createObjectNode();
            node.put("message", "An error occured. Check on server.");
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(node.toString()).build();
        }  
    }

    @RolesAllowed("ADMIN")
    @DELETE
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteBook(@PathParam("id") long id){
        ObjectMapper om = new ObjectMapper();
        try {
            SqlSessionFactory factory = Tools.getSqlSessionFactory(); 
            try(SqlSession session = factory.openSession();){
                session.delete("deleteBookById", id);
                session.commit();
                ObjectNode node = om.createObjectNode();
                node.put("message", "Book successfully deleted.");
                return Response.status(Status.OK).entity(node.toPrettyString()).build();
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.toString());
            ObjectNode node = om.createObjectNode();
            node.put("message", "An error occured. Check on server.");
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(node.toString()).build();
        }  
    }
}
