package atm.paradigms;

import org.glassfish.jersey.server.ResourceConfig;
import atm.paradigms.provider.AuthenticationFilter;

public class CustomApplication extends ResourceConfig {

    public CustomApplication() {
        packages("atm.paradigms");
        register(AuthenticationFilter.class);
    }
}
