package atm.paradigms.model;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface Mapper {
    @Select("SELECT * FROM MyBooks ORDER BY Id")
    public List<Book> getBooks();

    @Select("SELECT * FROM MyBooks WHERE Id = #{id}")
    public Book getBookById(Long id);

    @Insert("INSERT INTO MyBooks(Author, Title, Published, Remark) "
    + "VALUES(#{author}, #{title}, #{published}, #{remark})")
    public void insertBook(Book book);

    @Update("UPDATE MyBooks SET Author=#{author}, Title=#{title}, "
    + "Published=#{published}, Remark=#{remark} WHERE Id = #{id}")
    public void updateBook(Book book);

    @Delete("DELETE FROM MyBooks WHERE Id = #{id}")
    public void deleteBookById(Long id);
}
