package atm.paradigms.provider;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

@Provider
public class AuthenticationFilter implements ContainerRequestFilter {
    @Context
    private ResourceInfo resopuInfo;
    private static final String AUTHORIZATION_PROPERTY = "Authorization";
    private static final String AUTHENTICATION_SCHEME = "Basic";

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        Method method = resopuInfo.getResourceMethod();
        // access not allowed for all
        if (!method.isAnnotationPresent(PermitAll.class)) {
            // access deny for all
            if (method.isAnnotationPresent(DenyAll.class)) {
                requestContext.abortWith(Response
                        .status(Response.Status.FORBIDDEN)
                        .entity("Access blocked for all users!!").build());
                return;
            }
            // get request headers
            final MultivaluedMap<String, String> headers = requestContext.getHeaders();
            // get authorization header
            final List<String> authorization = headers.get(AUTHORIZATION_PROPERTY);
            // block access if no authorization
            if (authorization == null || authorization.isEmpty()) {
                requestContext.abortWith(Response
                        .status(Response.Status.FORBIDDEN)
                        .entity("You cannot access this resource!!").build());
                return;
            }
            // get encoded credentials
            final String encodedCredentials = authorization.get(0)
                    .replaceFirst(AUTHENTICATION_SCHEME + " ", "");
            // decode credentials
            final String credentials = new String(Base64.getDecoder().decode(encodedCredentials));
            // split userbane and password
            final StringTokenizer tokenizer = new StringTokenizer(credentials, ":");
            final String username = tokenizer.nextToken();
            final String password = tokenizer.nextToken();
            // verify user access
            if (method.isAnnotationPresent(RolesAllowed.class)) {
                RolesAllowed rolesAnnotation = method.getAnnotation(RolesAllowed.class);
                Set<String> rolesSet = new HashSet<>(Arrays.asList(rolesAnnotation.value()));
                // user not valid
                if (!isUserAllowed(username, password, rolesSet)) {
                    requestContext.abortWith(Response
                            .status(Response.Status.FORBIDDEN)
                            .entity("You cannot access this resource!!").build());
                    return;
                }
            }

        }
    }

    private boolean isUserAllowed(final String username, final String password, final Set<String> rolesSet) {
        boolean isAllowed = false;
        if (username.endsWith("user") && password.equals("password")) {
            // mock role
            String role = "ADMIN";
            if (rolesSet.contains(role)) {
                isAllowed = true;
            }
        }
        return isAllowed;
    }

}
