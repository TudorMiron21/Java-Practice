
package atm.paradigms;

import java.util.List;

import atm.paradigms.model.Book;

public class RestClientTest {
    public static void main(String[] args) {
        RestClient rc = new RestClient("user", "password");
        // get all books
        // List<Book> books = rc.getAllBooks();
        // System.out.println(books);
        //get book by Id
        // Book book = rc.getBookById(1);
        // System.out.println(book);
        // add new book
        Book book = new Book("Marin Preda", "Cel mai iubit dintre pamanteni", 1980, "Romania after 1945");
        rc.addBook(book);
        // update book
        // Book book = new Book("Marin Preda", "Morometii", 1955, "Romania before and after 1945");
        // rc.updateBook(22, book);
        // delete one book by Id
        // rc.deleteeBookById(23);
    }
}
