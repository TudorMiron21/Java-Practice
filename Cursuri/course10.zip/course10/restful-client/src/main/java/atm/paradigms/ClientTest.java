package atm.paradigms;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

import atm.paradigms.model.Book;

public class ClientTest {
    public static void main(String[] args) {
        Client client = ClientBuilder.newClient();
        String BASE_URI = "http://localhost:8080/restful-service/webapi";
        WebTarget webTarget = client.target(BASE_URI);
        // append book URI to BASE_URI
        WebTarget resource = webTarget.path("book");
        // build the request
        Builder builder = resource.request(MediaType.APPLICATION_JSON);
        // build a GET request
        Invocation invocation = builder.buildGet();
        // specify format type
        GenericType<List<Book>> responseType = new GenericType<List<Book>>(){ };
        List<Book> books = invocation.invoke(responseType);
        System.out.println(books);
    }
}
