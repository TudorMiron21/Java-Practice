package atm.paradigms;

import java.util.Base64;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

import atm.paradigms.model.Book;

public class RestClient {
    private static final Logger logger = Logger.getLogger(RestClient.class.getName());
    private final String BASE_URI = "http://localhost:8080/restful-service/webapi";
    private Client client;
    private String authEnc;

    public RestClient() {
        client = ClientBuilder.newClient();
    }

    public RestClient(String username, String password) {
        client = ClientBuilder.newClient();
        // String credentials = username + ":" + password;
        // authEnc = new String(Base64.getEncoder().encode(credentials.getBytes()));
        HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic(username, password);
        client.register(feature);
    }

    public List<Book> getAllBooks() {
        String url = BASE_URI + "/book";
        Response response = client.target(url).request()
                .accept(MediaType.APPLICATION_JSON)
                .get();
        GenericType<List<Book>> responseType = new GenericType<List<Book>>() {
        };
        return response.readEntity(responseType);
    }

    public Book getBookById(long id) {
        String url = BASE_URI + "/book/" + id;
        Response response = client.target(url).request()
                .accept(MediaType.APPLICATION_JSON)
                .get();
        return response.readEntity(Book.class);
    }

    public void addBook(Book book) {
        String url = BASE_URI + "/book";
        Response response = client.target(url).request(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                // .header("Authorization", "Basic " + authEnc)
                .post(Entity.entity(book, MediaType.APPLICATION_JSON));
        if (response.getStatus() == Status.CREATED.getStatusCode()) {
            logger.log(Level.INFO, "Book successfully saved.");
        }
    }

    public void updateBook(long id, Book book) {
        String url = BASE_URI + "/book/" + id;
        Response response = client.target(url).request(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                // .header("Authorization", "Basic " + authEnc)
                .put(Entity.entity(book, MediaType.APPLICATION_JSON));
        if (response.getStatus() == Status.CREATED.getStatusCode()) {
            logger.log(Level.INFO, "Book successfully updated.");
        }
    }

    public void deleteeBookById(long id) {
        String url = BASE_URI + "/book/" + id;
        Response response = client.target(url).request(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                // .header("Authorization", "Basic " + authEnc)
                .delete();
        if (response.getStatus() == Status.OK.getStatusCode()) {
            logger.log(Level.INFO, "Book successfully deleted.");
        }
    }
}
