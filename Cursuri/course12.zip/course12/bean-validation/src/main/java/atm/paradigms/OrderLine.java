package atm.paradigms;

public class OrderLine {
    public String item;
    public Double unitPrice;
    public Integer quantity;

    public OrderLine() {
    }

    public OrderLine(String item, Double unitPrice, Integer quantity) {
        this.item = item;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
    }
}
