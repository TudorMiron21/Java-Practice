package atm.paradigms;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Set;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
public class BookTest {
    @Inject
    Validator validator;

    @Test
    void shouldRaiseNoConstraintViolation() {

        Book book = new Book();
        book.title = "title";
        book.price = 2.99F;
        book.description = "description";
        book.nbOfPages = 10;
        book.authorEmail = "agoncal.fascicle@gmail.com";

        Set<ConstraintViolation<Book>> violations = validator.validate(book);
        assertEquals(0, violations.size());
    }

    @Test
    void shouldRaiseViolationDueToEmail() {

        Book book = new Book();
        book.title = "title";
        book.price = 2.99F;
        book.description = "description";
        book.nbOfPages = 10;
        book.authorEmail = "dummy";

        Set<ConstraintViolation<Book>> violations = validator.validate(book);
        assertEquals(1, violations.size());
    }

}
