package atm.paradigms;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Set;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
public class CDTest {
    @Inject
    Validator validator;

    @Test
    void shouldRaiseNoConstraintViolationWithDefault() {
        CD cd = new CD().title("Kind of Blue").price(12.5f);

        Set<ConstraintViolation<CD>> violations = validator.validate(cd);
        assertEquals(0, violations.size());
    }

    @Test
    void shouldRaiseConstraintViolationCausePriceIsNegative() {
        CD cd = new CD().title("Kind of Blue").price(-10f);

        Set<ConstraintViolation<CD>> violations = validator.validate(cd);
        assertEquals(1, violations.size());
        ConstraintViolation<CD> violation = violations.iterator().next();
        assertEquals("Kind of Blue", violation.getRootBean().title);
    }
}
