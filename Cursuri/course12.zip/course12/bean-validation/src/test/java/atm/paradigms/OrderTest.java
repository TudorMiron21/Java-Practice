package atm.paradigms;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Set;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
public class OrderTest {
    @Inject
    Validator validator;
    private static Instant creationDate = Instant.MIN;
    private static LocalDate deliveryDate = LocalDate.MAX;

    @Test
    void shouldRaiseNoConstraintViolation() {

        Order order = new Order(creationDate);
        order.orderId = "C45678";
        order.totalAmount = BigDecimal.valueOf(1234.5);
        order.deliveryDate = deliveryDate;
        order.addOrderLine(new OrderLine("item", 12d, 2));

        Set<ConstraintViolation<Order>> violations = validator.validate(order);
        assertEquals(0, violations.size());
    }

    @Test
    void shouldRaiseViolationDueToWrongPattern() {

        Order order = new Order(creationDate);
        order.orderId = "CDM45678";
        order.totalAmount = BigDecimal.valueOf(1234.5);
        order.deliveryDate = deliveryDate;
        order.addOrderLine(new OrderLine("item", 12d, 2));

        Set<ConstraintViolation<Order>> violations = validator.validate(order);
        assertEquals(1, violations.size());
    }
}
