package atm.paradigms;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;

import atm.paradigms.model.Book;
import atm.paradigms.model.Language;
import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.panache.common.Parameters;
import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
@Transactional
public class BookTest {
    @Test
    void shouldFind() {
        // Find returns a PanacheQuery
        PanacheQuery<Book> bookQuery = Book.find("nbOfPages > 100 ORDER BY title");
        List<Book> books = bookQuery.list();
        Long nbBooks = bookQuery.count();
        Book firstBook = bookQuery.firstResult();
        Optional<Book> oBook = bookQuery.firstResultOptional();
        assertEquals(5, books.size());
        assertEquals(5, nbBooks);
        assertEquals("Beginning Java EE 7", firstBook.title);
        assertEquals("Beginning Java EE 7", oBook.get().title);
        // list() is a shortcut to find().list()
        books = Book.find("nbOfPages > 100 ORDER BY title").list();
        assertEquals(5, books.size());
        books = Book.list("nbOfPages > 100 ORDER BY title");
        assertEquals(5, books.size());
    }

    @Test
    void shouldQueryWithParameters() {
        float min = 0f;
        float max = 30f;
        List<Book> cheapBooks;
        // Hard coded parameters
        cheapBooks = Book.list("unitCost between 0 and 30");
        assertEquals(1, cheapBooks.size());
        // Positional parameters
        cheapBooks = Book.list("unitCost between ?1 and ?2", min, max);
        assertEquals(1, cheapBooks.size());
        // Named parameters
        Map<String, Object> params = Map.of("min", min, "max", max);
        cheapBooks = Book.list("unitCost between :min and :max", params);
        assertEquals(1, cheapBooks.size());
        // Using the Parameters class
        cheapBooks = Book.list("unitCost between :min and :max",
                Parameters.with("min", min).and("max", max));
        assertEquals(1, cheapBooks.size());
        // Passing an enumeration
        List<Book> englishBooks = Book.list("language", Language.ENGLISH);
        assertEquals(4, englishBooks.size());
    }
}
