package atm.paradigms;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;

import atm.paradigms.model.Publisher;
import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
@Transactional
public class PublisherTest {
    @Test
    void shouldManagePublishers() {
        // Creates a publisher
        Publisher publisher = new Publisher();
        publisher.name = "AGoncal Fascicle";
        publisher.persist();
        Long publisherId = publisher.id;
        assertNotNull(publisherId);
        // Gets a list of all publisher entities
        List<Publisher> allPublishers = Publisher.listAll();
        assertTrue(allPublishers.size() >= 1);
        // Finds a specific publisher by ID
        publisher = Publisher.findById(publisherId);
        assertEquals("AGoncal Fascicle", publisher.name);
        // Counts all publishers
        long countAll = Publisher.count();
        assertTrue(countAll >= 1);
        // Checks if it's persistent
        if (publisher.isPersistent()) {
            // Deletes it
            publisher.delete();
        }
        // Deletes by id
        boolean deleted = Publisher.deleteById(publisherId);
        assertFalse(deleted);
        // assertThrows(PersistenceException.class, () -> {
        //     Publisher.deleteAll();
        // });
    }
}
