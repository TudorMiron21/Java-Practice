package atm.paradigms.model;

import java.time.Instant;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import io.quarkus.hibernate.orm.panache.PanacheEntity;
import io.quarkus.panache.common.Parameters;
import io.quarkus.panache.common.Sort;

@Entity
public class Book extends PanacheEntity {
    @Column(length = 100)
    public String title;
    @Column(name = "unit_cost")
    public Float unitCost;
    @Column(length = 3000)
    public String description;
    @Column(length = 15)
    public String isbn;
    @Column(name = "nb_of_pages")
    public Integer nbOfPages;
    @Column(name = "publication_date")
    public Instant publicationDate;
    @Enumerated(EnumType.STRING)
    public Language language;
    @ManyToOne
    @JoinColumn(name = "publisher_pk")
    public Publisher publisher;

    public static List<Book> findEnglishBooks() {
        return list("language", Language.ENGLISH);
    }

    public static long countEnglishBooks() {
        return count("language", Language.ENGLISH);
    }

    public static List<Book> findBetweenPrices(Float min, Float max) {
        return list("unitCost between :min and :max",
                Parameters.with("min", min).and("max", max));
    }

    public static List<Book> findAllOrderByTitle() {
        return listAll(Sort.by("title").and("publicationDate"));
    }
}
