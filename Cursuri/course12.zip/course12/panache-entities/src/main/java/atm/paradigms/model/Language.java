package atm.paradigms.model;

public enum Language {
    ENGLISH, FRENCH, SPANISH, PORTUGUESE, ROMANIAN, RUSSIAN, CHINESE, INDIAN, GERMAN, JAPANESE
}
