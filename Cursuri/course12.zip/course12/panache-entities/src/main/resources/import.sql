INSERT INTO PUBLISHER (ID, NAME) VALUES (1001, 'APress');
INSERT INTO PUBLISHER (ID, NAME) VALUES (1002, 'Manning');
INSERT INTO PUBLISHER (ID, NAME) VALUES (1003, 'O Reilly');
INSERT INTO PUBLISHER (ID, NAME) VALUES (1004, 'Addison-Wesley');
INSERT INTO PUBLISHER (ID, NAME) VALUES (1005, 'John Wiley');
INSERT INTO PUBLISHER (ID, NAME) VALUES (1006, 'MIT Press');
INSERT INTO PUBLISHER (ID, NAME) VALUES (1007, 'Packt');
INSERT INTO PUBLISHER (ID, NAME) VALUES (1008, 'The Pragmatic Programmer');
INSERT INTO PUBLISHER (ID, NAME) VALUES (1009, 'Prentice Hall');
INSERT INTO PUBLISHER (ID, NAME) VALUES (1010, 'Wrox Press');

INSERT INTO BOOK (ID, TITLE, UNIT_COST, ISBN, LANGUAGE, NB_OF_PAGES, PUBLICATION_DATE, PUBLISHER_PK, DESCRIPTION) VALUES (1000, 'Beginning Java EE 7', 49.99, '143024626X', 'ENGLISH', 608, '2014-02-05', 1001, 'Java Enterprise Edition (Java EE) continues to be one of the leading Java technologies and platforms. Beginning Java EE 7 is the first tutorial book on Java EE 7. Step by step and easy to follow, this book describes many of the Java EE 7 specifications...');
INSERT INTO BOOK (ID, TITLE, UNIT_COST, ISBN, LANGUAGE, NB_OF_PAGES, PUBLICATION_DATE, PUBLISHER_PK, DESCRIPTION) VALUES (2000, 'Java EE 7 Essentials', 39.99, '1449370179', 'ENGLISH', 362, '2014-02-05', 1002, 'Get up to speed on the principal technologies in the Java Platform, Enterprise Edition 7, and learn how the latest version embraces HTML5, focuses on higher productivity, and provides functionality to meet enterprise demands. Written by Arun Gupta, a k...');
INSERT INTO BOOK (ID, TITLE, UNIT_COST, ISBN, LANGUAGE, NB_OF_PAGES, PUBLICATION_DATE, PUBLISHER_PK, DESCRIPTION) VALUES (3000, 'Java EE 7 Recipes: A Problem-Solution Approach', 49.99, '1430244259', 'ENGLISH', 748, '2014-02-05', 1003, 'Java EE 7 Recipes takes an example-based approach in showing how to program Enterprise Java applications in many different scenarios. Be it a small-business web application, or an enterprise database application, Java EE 7 Recipes provides effective an...');
INSERT INTO BOOK (ID, TITLE, UNIT_COST, ISBN, LANGUAGE, NB_OF_PAGES, PUBLICATION_DATE, PUBLISHER_PK, DESCRIPTION) VALUES (4000, 'Introducing Java EE 7: A Look at What''s New', 29.99, '1430258489', 'ENGLISH', 240, '2014-02-05', 1004, 'Introducing Java EE 7:  A Look at What’s New&lt;/em&gt; guides you through the new features and enhancements in each of the technologies comprising the Java EE platform.  Readers of this book will not have to wade through introductory material or infor...');
INSERT INTO BOOK (ID, TITLE, UNIT_COST, ISBN, LANGUAGE, NB_OF_PAGES, PUBLICATION_DATE, PUBLISHER_PK, DESCRIPTION) VALUES (5000, 'Oracle Certified Master Java Enterprise Architect Java EE 7: Certification Guide', 49.99, '1430250011', 'FRENCH', 700, '2014-02-05', 1005, 'Oracle Certified Master, Java Enterprise Architect Java EE 7 Certification Guide is a practical hands on guide for those looking to achieve the Master certification. It deals with the different technological aspects necessary to prop up the understandi...');

