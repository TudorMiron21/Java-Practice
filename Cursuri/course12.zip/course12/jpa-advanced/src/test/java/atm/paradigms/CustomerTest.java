package atm.paradigms;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
public class CustomerTest {
    @Inject
    EntityManager em;

    @Test
    @Transactional
    public void shouldPersistACustomerWithOneAddressSet() {
        Customer customer = new Customer("Anthony", "Balla", "aballa@mail.com");
        Address address = new Address("Ritherdon Rd", "London", "8QE", "UK");
        customer.setAddress(address);
        // Persists the object
        em.persist(customer);
        em.persist(address);

        assertNotNull(customer.getId());
        assertNotNull(address.getId());
    }

    @Test
    @Transactional
    public void shouldFindACustomer() throws Exception {

        Customer createdCustomer = new Customer("Anthony", "Balla", "aballa@mail.com");
        Address createdAddress = new Address("Ritherdon Rd", "London", "8QE", "UK");
        createdCustomer.setAddress(createdAddress);

        // Persists the object
        em.persist(createdCustomer);
        em.persist(createdAddress);
        em.flush();

        assertNotNull(createdCustomer.getId());
        assertNotNull(createdAddress.getId());
        Long id = createdCustomer.getId();

        // Clear
        em.clear();

        Customer customer = em.find(Customer.class, id);
        if (customer != null) {
            // Process the object
        }
        assertNotNull(customer);
    }

    @Test
    @Transactional
    public void shouldRemoveACustomer() throws Exception {
        Customer customer = new Customer("Anthony", "Balla", "aballa@mail.com");
        Address address = new Address("Ritherdon Rd", "London", "8QE", "UK");
        customer.setAddress(address);
        // Persists the object
        em.persist(customer);
        em.persist(address);
        assertNotNull(customer.getId());
        assertNotNull(address.getId());
        // Removes the object from the database
        em.remove(customer);
        em.remove(address);
        // The entities are not in the database
        assertNull(em.find(Customer.class, customer.getId()));
        assertNull(em.find(Address.class, address.getId()));
    }
}
