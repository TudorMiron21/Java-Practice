-- This file allow to write SQL commands that will be emitted in test and dev.
-- The commands are commented as their support depends of the database
-- insert into myentity (id, field) values(nextval('hibernate_sequence'), 'field-1');
-- insert into myentity (id, field) values(nextval('hibernate_sequence'), 'field-2');
-- insert into myentity (id, field) values(nextval('hibernate_sequence'), 'field-3');

-- DROP TABLE CUSTOMER;
-- DROP TABLE ADDRESS;
-- CREATE TABLE ADDRESS
-- (
-- ID INTEGER NOT NULL PRIMARY KEY,
-- STREEET VARCHAR(255),
-- ZIPCODE VARCHAR(255),
-- CITY VARCHAR(255),
-- COUNTRY VARCHAR(255)
-- );
-- CREATE TABLE CUSTOMER
-- (
-- ID INTEGER NOT NULL PRIMARY KEY,
-- FIRSTNAME VARCHAR(255),
-- LASTNAME VARCHAR(255),
-- EMAIL VARCHAR(255),
-- ADDRESS INTEGER,
-- CONSTRAINT ADDRESS_FK FOREIGN KEY (ADDRESS)
-- REFERENCES ADDRESS(ID)
-- );



