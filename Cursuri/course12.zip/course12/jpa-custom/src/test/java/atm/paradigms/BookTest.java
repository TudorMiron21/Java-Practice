package atm.paradigms;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
public class BookTest {
    @Inject
    EntityManager entityManager;

    @Test
    @Transactional
    void shouldCreateABook() {
        Book book = new Book();
        book.setTitle("Morometzi");
        book.setNbOfPages(345);
        entityManager.persist(book);
        assertNotNull(book.getId(), "Id should not be null");
    }
}
