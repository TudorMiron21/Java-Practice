package atm.paradigms.service;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import atm.paradigms.model.Book;

@ApplicationScoped
@Transactional
public class BookService {
    @Inject
    EntityManager em;

    public List<Book> findBooks() {
        return em.createQuery("SELECT b FROM Book b", Book.class).getResultList();
    }

    public Book createBook(Book book) {
        em.persist(book);
        return book;
    }
}
