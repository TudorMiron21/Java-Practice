package atm.paradigms.service;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import atm.paradigms.model.Publisher;

import static javax.transaction.Transactional.TxType.SUPPORTS;
import static javax.transaction.Transactional.TxType.REQUIRED;

import java.util.List;

@ApplicationScoped
@Transactional(SUPPORTS)
public class PublisherService {
    @Inject
    EntityManager em;

    @Transactional(REQUIRED)
    public Publisher persist(Publisher publisher) {
        em.persist(publisher);
        return publisher;
    }

    @Transactional(REQUIRED)
    public Publisher update(Publisher publisher) {
        return em.merge(publisher);
    }

    @Transactional(REQUIRED)
    public void deleteById(Long id) {
        em.remove(em.find(Publisher.class, id));
    }

    @Transactional(REQUIRED)
    public int deleteByName(String name) {
        int rowsDeleted = em.createQuery("DELETE FROM Publisher p WHERE p.name = :name ")
                .setParameter("name", name)
                .executeUpdate();
        return rowsDeleted;
    }

    public List<Publisher> findAll() {
        return em.createQuery("SELECT p FROM Publisher p", Publisher.class).getResultList();
    }

    

}
