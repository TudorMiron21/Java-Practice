package atm.paradigms;

import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.inject.Inject;

import org.junit.jupiter.api.Test;

import atm.paradigms.model.Book;
import atm.paradigms.service.BookService;
import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
public class BookServiceTest {

    @Inject
    BookService bookService;

    @Test
    void shouldAddABook() {
        // persist bokk
        Book book = new Book();
        book.setTitle("Morometzi");
        book.setIllustrations(false);
        book.setPrice(24.5f);
        book.setNbOfPages(255);

        book = bookService.createBook(book);
        assertEquals(1, bookService.findBooks().size());
    }

}
