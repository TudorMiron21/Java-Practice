package atm.paradigms;

import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.inject.Inject;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import atm.paradigms.model.Publisher;
import atm.paradigms.service.PublisherService;
import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class PublisherServiceTest {

    @Inject
    PublisherService publisherService;

    private static long publisherId;

    @Test
    @Order(1)
    void shouldAddAnPublisher() {
        Publisher publisher = new Publisher();
        publisher.setName("First publisher");
        publisher = publisherService.persist(publisher);
        assertEquals(1, publisherService.findAll().size());
        publisherId = publisher.getId();
    }

    @Test
    @Order(2)
    void shouldUpdateAPublisher() {
        Publisher publisher = new Publisher();
        publisher.setId(publisherId);
        publisher.setName("Updated Publisher");
        // Updates the previously created publisher
        publisherService.update(publisher);
        assertEquals(1, publisherService.findAll().size());
    }

    @Test
    @Order(3)
    void shouldRemoveAPublisher() {
        // Deletes the previously created publisher
        publisherService.deleteById(publisherId);
        // Checks there is less a publisher in the database
        assertEquals(0, publisherService.findAll().size());
    }

}
